
<h1>Pyber Ride Sharing</h1>

Assignment:  Matplotlib Homework<br/>
Organization:  USC Viterbi Analytics Bootcamp, 1/30<br/>
Author:  Patrick Humphries<br/>
Date:  March 7, 2018

<h2>Analysis</h2>
<ul>
<li>Rural drivers make up only 3.1% of the drivers but they bring in 6.6% of the revenue.  Hence rural drivers earn twice as much as urban drivers.</li>
<li>Rides, drivers, and revenue is dominated by urban city types.</li>
<li>Urban fares are low but the frequency of rides is high, resulting in high revenue</li>
</ul>


```python
# Dependencies
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib.patches as mpatches
```


```python
# Read City Data
city_data_csv = "raw_data/city_data.csv"
df_city = pd.read_csv(city_data_csv)
df_city.head() # 126 x 3
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Rename type to city_type to avoid confusion with a keyword.
df_city = df_city.rename(columns={"type":"city_type"})
df_city.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>city_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Read Ride Data
ride_data_csv = "raw_data/ride_data.csv"
df_ride = pd.read_csv(ride_data_csv)
df_ride.head() # 2375 x 4
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Aggregate Fares and Rides.
df_ride_agg = pd.DataFrame(df_ride.groupby('city').agg({'fare': ['mean', 'count']}))

# Remove the high-level label as a result of the aggregation.
df_ride_agg = df_ride_agg.get('fare')

# Move the city index values into a column.
df_ride_agg = df_ride_agg.reset_index()

# Convert the mean fare to an integer.
df_ride_agg['mean'] = [int(x) for x in df_ride_agg['mean']]

# Rename the aggregation headings to the corresponding attributes.
df_ride_agg = df_ride_agg.rename(columns={"mean":"fare", "count":"rides"})

df_ride_agg.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>fare</th>
      <th>rides</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>23</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>20</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>37</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>23</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>21</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Merge city and ride data.
df_merged = pd.merge(df_city, df_ride_agg)
df_merged.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>city_type</th>
      <th>fare</th>
      <th>rides</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>21</td>
      <td>28</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>25</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>26</td>
      <td>22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>22</td>
      <td>29</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>21</td>
      <td>23</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Calculate revenue for pie charts.
df_merged['revenue'] = df_merged['fare'] * df_merged['rides']
df_merged.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>city_type</th>
      <th>fare</th>
      <th>rides</th>
      <th>revenue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>21</td>
      <td>28</td>
      <td>588</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>25</td>
      <td>26</td>
      <td>650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>26</td>
      <td>22</td>
      <td>572</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>22</td>
      <td>29</td>
      <td>638</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>21</td>
      <td>23</td>
      <td>483</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Define a function that translates city type into color.
def select_facecolor(city_type):
    if city_type == "Urban":
        return "lightcoral"
    if city_type == "Suburban":
        return "lightskyblue"
    return "gold"
```


```python
# Add color to the merged data based on city type.
df_merged['facecolor'] = [select_facecolor(x) for x in df_merged['city_type']]
df_merged.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>city_type</th>
      <th>fare</th>
      <th>rides</th>
      <th>revenue</th>
      <th>facecolor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>21</td>
      <td>28</td>
      <td>588</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>25</td>
      <td>26</td>
      <td>650</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>26</td>
      <td>22</td>
      <td>572</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>22</td>
      <td>29</td>
      <td>638</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>21</td>
      <td>23</td>
      <td>483</td>
      <td>lightcoral</td>
    </tr>
  </tbody>
</table>
</div>



<h2>Bubble Plot of Ride Sharing Data</h2>


```python
# Plot the merged dataframe.

# Lists are used for x axis, y axis, bubble size, and bubble color.
plt.figure(figsize=(20,12))

# Get number of rides per city for the horizontal axis.
list_rides = list(df_merged.loc[:,'rides'])
    
# Get average fares per city for the verticle axis.
list_fares = list(df_merged.loc[:,'fare'])
    
# Calculate revenue, to be used in pie chars.
list_revenue = list(df_merged.loc[:,'revenue'])

# Get driver count for bubble size.
list_driver_count = list(df_merged.loc[:,'driver_count'])

# Scale up the driver count for appropiate size on bubble chart.
list_driver_count = [x * 40 for x in list_driver_count]

# Get facecolor for bubble color representing city type.
list_facecolors = list(df_merged.loc[:,'facecolor'])

# Plot the four lists.
plt.scatter(list_rides, list_fares, list_driver_count, marker="o", facecolors=list_facecolors, edgecolors="black")

# Add labels and grid.
plt.xlabel('Total Number of Rides (Per Ciity)')
plt.ylabel('Average Fares ($)')
plt.title('Pyber Ride Sharing Data (2016)')
plt.grid()

# Add a custom legend.
urban_patch = mpatches.Patch(color='lightcoral', label='Urban')
suburban_patch = mpatches.Patch(color='lightskyblue', label='Suburban')
rural_patch = mpatches.Patch(color='gold', label='Rural')
plt.legend(title="City Types\nCircle size correlates with driver count per city", fontsize='x-large', handles=[urban_patch, suburban_patch, rural_patch])

# Show the bubble chart.
plt.show()
```


![png](output_11_0.png)


<h2>Total Fares by City Type</h2>


```python
# Determining that city type and revenue are needed for revenue pie chart.
df_merged.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>city_type</th>
      <th>fare</th>
      <th>rides</th>
      <th>revenue</th>
      <th>facecolor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>21</td>
      <td>28</td>
      <td>588</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
      <td>25</td>
      <td>26</td>
      <td>650</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
      <td>26</td>
      <td>22</td>
      <td>572</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
      <td>22</td>
      <td>29</td>
      <td>638</td>
      <td>lightcoral</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
      <td>21</td>
      <td>23</td>
      <td>483</td>
      <td>lightcoral</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Aggregate revenue by city type.
df_revenue = pd.DataFrame(df_merged.groupby('city_type').agg({'revenue': ['sum']}))

# Remove high-level labels as result of the aggregation.
df_revenue = df_revenue['revenue']

# Rename the aggregated column to the corresponding attribute.
df_revenue = df_revenue.rename(columns={"sum":"revenue"})

# Move city type index to a column.
df_revenue = df_revenue.reset_index()

# Add colors that correspond to the city type.
df_revenue['facecolor'] = [select_facecolor(x) for x in df_revenue['city_type']]

# Show revenue parameters.
df_revenue
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city_type</th>
      <th>revenue</th>
      <th>facecolor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>4195</td>
      <td>gold</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>19990</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>39285</td>
      <td>lightcoral</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart.
labels = list(df_revenue['city_type'])

# Values of each section of the pie chart.
sizes = list(df_revenue['revenue'])

# Colors of each section of the pie chart.
colors = list(df_revenue['facecolor'])

# Separate slices.
explode = (0.1, 0.1, 0.1)
```


```python
# Creates the pie chart based upon the values above
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct="%1.1f%%", shadow=True, startangle=140)

# Prop up the pie chart.
plt.axis("equal")

# Add a title to the pie chart.
plt.title('% of Total Fares by City Type')

# Show the pie chart.
plt.show()
```


![png](output_16_0.png)


<h2>Total Rides by City Type</h2>


```python
# Aggregate rides by city type.
df_rides = pd.DataFrame(df_merged.groupby('city_type').agg({'rides': ['sum']}))

# Remove high-level label as result of the aggregation.
df_rides = df_rides['rides']

# Rename the aggregation labels to the corresponding attributes.
df_rides = df_rides.rename(columns={"sum":"rides"})

# Move city type to a column.
df_rides = df_rides.reset_index()

# A colors that correspond to the city type.
df_rides['facecolor'] = [select_facecolor(x) for x in df_rides['city_type']]

# Show rides parameters.
df_rides
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city_type</th>
      <th>rides</th>
      <th>facecolor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>125</td>
      <td>gold</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>657</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>1625</td>
      <td>lightcoral</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart.
labels = list(df_rides['city_type'])

# Values of each section of the pie chart.
sizes = list(df_rides['rides'])

# Colors of each section of the pie chart.
colors = list(df_rides['facecolor'])

# Separate slices.
explode = (0.1, 0.1, 0.1)
```


```python
# Creates the pie chart based upon the values above
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct="%1.1f%%", shadow=True, startangle=140)

# Prop up the pie chart.
plt.axis("equal")

# Add a title to the pie chart.
plt.title('% of Total Rides by City Type')

# Show the pie chart.
plt.show()
```


![png](output_20_0.png)


<h2>Total Drivers by City Type</h2>


```python
# Aggregate drivers by city type.
df_drivers = pd.DataFrame(df_merged.groupby('city_type').agg({'driver_count': ['sum']}))

# Remove the high-level label as result of the aggregation.
df_drivers = df_drivers['driver_count']

# Rename the aggregation label to the corresponding attribute.
df_drivers = df_drivers.rename(columns={"sum":"drivers"})

# Move city type to a column.
df_drivers = df_drivers.reset_index()

# Add colors that correspond to the city type.
df_drivers['facecolor'] = [select_facecolor(x) for x in df_drivers['city_type']]

# Show diver parameters.
df_drivers
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city_type</th>
      <th>drivers</th>
      <th>facecolor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>104</td>
      <td>gold</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>638</td>
      <td>lightskyblue</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>2607</td>
      <td>lightcoral</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Labels for the sections of our pie chart.
labels = list(df_drivers['city_type'])

# Values of each section of the pie chart.
sizes = list(df_drivers['drivers'])

# Colors of each section of the pie chart.
colors = list(df_drivers['facecolor'])

# Separate slices.
explode = (0.1, 0.1, 0.1)
```


```python
# Creates the pie chart based upon the values above
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct="%1.1f%%", shadow=True, startangle=140)

# Prop up the pie chart.
plt.axis("equal")

# Add a title to the pie chart.
plt.title('% of Total Drivers by City Type')

# Show the pie chart.
plt.show()
```


![png](output_24_0.png)


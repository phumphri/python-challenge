
## Unit 7 | Assignment - Distinguishing Sentiments

## Background

__Twitter__ has become a wildly sprawling jungle of information&mdash;140 characters at a time. Somewhere between 350 million and 500 million tweets are estimated to be sent out _per day_. With such an explosion of data, on Twitter and elsewhere, it becomes more important than ever to tame it in some way, to concisely capture the essence of the data.

## News Mood

In this assignment, you'll create a Python script to perform a sentiment analysis of the Twitter activity of various news oulets, and to present your findings visually.

Your final output should provide a visualized summary of the sentiments expressed in Tweets sent out by the following news organizations: __BBC, CBS, CNN, Fox, and New York times__.

![output_10_0.png](output_10_0.png)

![output_13_1.png](output_13_1.png)

The first plot will be and/or feature the following:

* Be a scatter plot of sentiments of the last __100__ tweets sent out by each news organization, ranging from -1.0 to 1.0, where a score of 0 expresses a neutral sentiment, -1 the most negative sentiment possible, and +1 the most positive sentiment possible.
* Each plot point will reflect the _compound_ sentiment of a tweet.
* Sort each plot point by its relative timestamp.

The second plot will be a bar plot visualizing the _overall_ sentiments of the last 100 tweets from each organization. For this plot, you will again aggregate the compound sentiments analyzed by VADER.

The tools of the trade you will need for your task as a data analyst include the following: tweepy, pandas, matplotlib, seaborn, textblob, and VADER.

Your final Jupyter notebook must:

* Pull last 100 tweets from each outlet.
* Perform a sentiment analysis with the compound, positive, neutral, and negative scoring for each tweet. 
* Pull into a DataFrame the tweet's source acount, its text, its date, and its compound, positive, neutral, and negative sentiment scores.
* Export the data in the DataFrame into a CSV file.
* Save PNG images for each plot.

As final considerations:

* Use the Matplotlib and Seaborn libraries.
* Include a written description of three observable trends based on the data. 
* Include proper labeling of your plots, including plot titles (with date of analysis) and axes labels.
* Include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  


## Copyright

Coding Boot Camp (C) 2017. All Rights Reserved.

<h2>Trends</h2>
<ul>
<li>Tweets from all media organizations range widely, but most are neutral</li>
<li>Fox News has an overall negative sentiment</li>
<li>CBS has an overall positive sentiment</li>
</ul>


```python
# Dependencies
from object_oriented_context import api # tweepy cursor does not work with JSON.
import object_oriented_context
import tweepy
import json
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from datetime import datetime
from datetime import timezone    
```

    Luis Cipher
    


```python
# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

analyzer = SentimentIntensityAnalyzer()
```


```python
# Select news orgainizations.
news_organizations = ['@BBC', '@CBS', '@CNN', '@FoxNews', '@nytimes']
```


```python
# Create an empty dataframe to store sentiment values.
df = pd.DataFrame(news_organizations)

# Rename column 0 to News for news organization.
df = df.rename(columns={0:"News"})

df['Timestamp'] = ""
df['Positive'] = 0.0
df['Neutral'] = 0.0
df['Negative'] = 0.0
df['Compound'] = 0.0
df['Tweet'] = ""

df.drop(df.head(len(news_organizations)).index, inplace = True)

df 
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>News</th>
      <th>Timestamp</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Tweet</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# Get 100 tweets per news organization then store the sentiment.
for target_user in news_organizations:

    # Twenty text entries per page.
    try:
        for page in tweepy.Cursor(api.user_timeline, id=target_user).pages(5):

            # Sleep for two seconds to avoid tweepy.RateLimitError
            time.sleep(2)

            for text_entry in page:

                content = text_entry.text
                
                # Run analysis
                compound = analyzer.polarity_scores(content)["compound"]
                pos = analyzer.polarity_scores(content)["pos"]
                neu = analyzer.polarity_scores(content)["neu"]
                neg = analyzer.polarity_scores(content)["neg"]

                row_index = len(df.index)

                df.set_value(row_index, 'News', target_user)
                df.set_value(row_index, 'Positive', pos)
                df.set_value(row_index, 'Neutral', neu)
                df.set_value(row_index, 'Negative', neg)
                df.set_value(row_index, 'Compound', compound)
                
                ts = datetime.strptime(text_entry._json["created_at"], '%a %b %d %H:%M:%S %z %Y')\
                    .replace(tzinfo=timezone.utc)\
                    .astimezone(tz=None).strftime('%Y-%m-%d %H:%M:%S')
                               
                df.set_value(row_index, 'Timestamp', ts)
                
                df.set_value(row_index, 'Tweet', content)
                
    except tweepy.RateLimitError as error:
        print("tweepy.RateLimitError was thrown:")
        print("Waiting one minute before proceeding.")    
        time.sleep(60)
    
df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>News</th>
      <th>Timestamp</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Tweet</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>2018-03-18 13:30:11</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>🏃💪 @LesDennis, @SimplySusannah, @Tameka_Empson...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@BBC</td>
      <td>2018-03-18 13:03:04</td>
      <td>0.090</td>
      <td>0.824</td>
      <td>0.086</td>
      <td>0.0258</td>
      <td>👎💌 Fans of K-Pop boyband member @IBGDRGN have ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@BBC</td>
      <td>2018-03-18 12:33:04</td>
      <td>0.197</td>
      <td>0.803</td>
      <td>0.000</td>
      <td>0.5994</td>
      <td>Saoirse Ronan stars as Eilis, a young girl who...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@BBC</td>
      <td>2018-03-18 11:44:02</td>
      <td>0.000</td>
      <td>0.837</td>
      <td>0.163</td>
      <td>-0.5994</td>
      <td>Ruth Ellis was only 28 when she became the las...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@BBC</td>
      <td>2018-03-18 11:34:14</td>
      <td>0.151</td>
      <td>0.772</td>
      <td>0.077</td>
      <td>0.2040</td>
      <td>RT @BBC_TopGear: 840bhp goes a little like thi...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Check for 100 tweets per media source.
len(df.index)
```




    500




```python
# Check if filtering works.
df2 = df.loc[df['News'] == '@BBC']
df2 = df2.sort_values(by=['Timestamp'])
df2.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>News</th>
      <th>Timestamp</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Tweet</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>99</th>
      <td>@BBC</td>
      <td>2018-03-14 01:35:41</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>Despite 8 million tonnes of plastic entering U...</td>
    </tr>
    <tr>
      <th>98</th>
      <td>@BBC</td>
      <td>2018-03-14 02:00:05</td>
      <td>0.252</td>
      <td>0.748</td>
      <td>0.0</td>
      <td>0.5719</td>
      <td>'I was homeless on these streets - I'm the per...</td>
    </tr>
    <tr>
      <th>97</th>
      <td>@BBC</td>
      <td>2018-03-14 03:01:19</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>RT @BBCArchive: Stephen Hawking first appeared...</td>
    </tr>
    <tr>
      <th>96</th>
      <td>@BBC</td>
      <td>2018-03-14 03:27:40</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>'You could ask my dad any question.'\n\nIn mem...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>@BBC</td>
      <td>2018-03-14 04:30:12</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.0</td>
      <td>0.0000</td>
      <td>💫 Stephen Hawking: A life in pictures.\n📸 👉 ht...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Format today's date for display.
date_str = datetime.today().strftime('%Y-%m-%d')
print(date_str)
```

    2018-03-18
    


```python
# Write weather dataframe to csv file.
df.to_csv("media_sentiment.csv")
```


```python
# Plot detail sentiments.
plt.figure(figsize=(20,12))

# Format axis
plt.xticks(np.arange(0, 110, 10))
plt.xlim(100, 0)
plt.yticks(np.arange(-2, 2, .5))

# Format labels
plt.xlabel('Tweets Ago')
plt.ylabel('Tweepy Polarity')
plt.title('Sentiment Analysis of Media Tweets (' + date_str + ')')

# Add a custom legend.
bbc_patch = mpatches.Patch(color='lightskyblue', label='BBC')
cbs_patch = mpatches.Patch(color='green', label='CBS')
cnn_patch = mpatches.Patch(color='red', label='CNN')
fox_patch = mpatches.Patch(color='blue', label='Fox News')
nyt_patch = mpatches.Patch(facecolor='yellow', edgecolor = 'black', label='The New York Times')
plt.legend(title="Media Sources", fontsize='x-large', \
           handles=[bbc_patch, cbs_patch, cnn_patch, fox_patch, nyt_patch])

# Process each news organization.
for news_organization in news_organizations:
 
    # Set the color for plotting the news organization.
    if news_organization == '@BBC':
        news_color = 'lightskyblue'
        edge_color = news_color
    elif news_organization == '@CBS':
        news_color = 'green'
        edge_color = news_color
    elif news_organization == '@CNN':
        news_color = 'red'
        edge_color = news_color
    elif news_organization == '@FoxNews':
        news_color = 'blue'
        edge_color = news_color
    elif news_organization == '@nytimes':
        news_color = 'yellow'
        edge_color = 'black'
    else:
        news_color = 'black'
    
    # Create a dataframe for the news organization for plotting.
    df2 = df.loc[df['News'] == news_organization]
    
    # Renumber the row index.  
    df2.index = pd.RangeIndex(len(df2.index))
    
    # Select and order the values.
    y_axis = list(reversed(df2.loc[:,'Compound']))
    x_axis = list(reversed(np.arange(0, len(y_axis))))
    
    # Plot the news organization.
    plt.scatter(x_axis, y_axis, color = news_color, edgecolors = edge_color)

# Show all plots.
plt.show()
```


![png](output_11_0.png)



```python
# Pull enough detail for the summary plot.
df3 = df.loc[:,['News', 'Compound']]
df3.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>News</th>
      <th>Compound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@BBC</td>
      <td>0.0258</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@BBC</td>
      <td>0.5994</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@BBC</td>
      <td>-0.5994</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@BBC</td>
      <td>0.2040</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Aggregate the mean compound score for each news organization.
df4 = df3.groupby('News').agg({'mean'})
df4.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>Compound</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
    </tr>
    <tr>
      <th>News</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>@BBC</th>
      <td>0.180383</td>
    </tr>
    <tr>
      <th>@CBS</th>
      <td>0.304366</td>
    </tr>
    <tr>
      <th>@CNN</th>
      <td>-0.037818</td>
    </tr>
    <tr>
      <th>@FoxNews</th>
      <td>-0.078719</td>
    </tr>
    <tr>
      <th>@nytimes</th>
      <td>0.000768</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Move the News row index into a column.
df5 = df4.reset_index()
df5
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>News</th>
      <th>Compound</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th>mean</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@BBC</td>
      <td>0.180383</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@CBS</td>
      <td>0.304366</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@CNN</td>
      <td>-0.037818</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@FoxNews</td>
      <td>-0.078719</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@nytimes</td>
      <td>0.000768</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Remove the top-level labels of News and Component.
df5.columns = df5.columns.droplevel(0)

# Sort rows by the mean compound value.
df5 = df5.sort_values(by='mean')

# Rename the columns.
df5.columns = ['News', 'Compound']

# Resequence the row key.
df5.index = pd.RangeIndex(len(df5.index))
df5
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>News</th>
      <th>Compound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>@FoxNews</td>
      <td>-0.078719</td>
    </tr>
    <tr>
      <th>1</th>
      <td>@CNN</td>
      <td>-0.037818</td>
    </tr>
    <tr>
      <th>2</th>
      <td>@nytimes</td>
      <td>0.000768</td>
    </tr>
    <tr>
      <th>3</th>
      <td>@BBC</td>
      <td>0.180383</td>
    </tr>
    <tr>
      <th>4</th>
      <td>@CBS</td>
      <td>0.304366</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Pull out values for the summary plot.
x_axis = list(df5.loc[:,'News'])
y_axis = df5['Compound']
print(x_axis)
print(y_axis)
```

    ['@FoxNews', '@CNN', '@nytimes', '@BBC', '@CBS']
    0   -0.078719
    1   -0.037818
    2    0.000768
    3    0.180383
    4    0.304366
    Name: Compound, dtype: float64
    


```python
# Create a scatter plot of compound sentiment values.
plt.figure(figsize=(20,12))

# Format labels
plt.xlabel('News Organization')
plt.ylabel('Tweepy Polarity')
plt.title('Overall Sentiment of Media Tweets (' + date_str + ')')


x_range = np.arange(0, len(df5.index))

for i in x_range:
    
        # Set the color for plotting the news organization.
    if x_axis[i] == '@BBC':
        news_color = 'lightskyblue'
        edge_color = news_color
    elif x_axis[i] == '@CBS':
        news_color = 'green'
        edge_color = news_color
    elif x_axis[i] == '@CNN':
        news_color = 'red'
        edge_color = news_color
    elif x_axis[i] == '@FoxNews':
        news_color = 'blue'
        edge_color = news_color
    elif x_axis[i] == '@nytimes':
        news_color = 'yellow'
        edge_color = 'black'
    else:
        news_color = 'black'
  
    plt.bar(i, y_axis[i], facecolor = news_color)
    
plt.xticks(x_range, x_axis)



    
plt.show()
```


![png](output_17_0.png)


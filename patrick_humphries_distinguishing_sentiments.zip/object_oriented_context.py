import tweepy

consumer_key="YhICRiL9rXjMj5gC74v8Bi7Wa"
consumer_secret="RhPW6tVd7j8GC6wP9byWE7hdvAxmo6s15H6LappofOm5iByF7U"

access_token="973957423152095232-BlngqUDT7UhLsl3I6mSW9YXNkL5401H"
access_token_secret="b20uzJQa76vxhzdzmdv6QVVH1Dt7BDT5BezJiKDkgoxWO"

# Set Authentication Handler
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth_handler=auth)


user_object = api.me()

print(user_object.name)
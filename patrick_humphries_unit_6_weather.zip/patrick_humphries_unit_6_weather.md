
## Unit 6 | Assignment - What's the Weather Like?

## Background

Whether financial, political, or social -- data's true power lies in its ability to answer questions definitively. So let's take what you've learned about Python requests, APIs, and JSON traversals to answer a fundamental question: "What's the weather like as we approach the equator?"

Now, we know what you may be thinking: _"Duh. It gets hotter..."_ 

But, if pressed, how would you **prove** it? 

![Equator](equatorsign.png)

## WeatherPy

In this example, you'll be creating a Python script to visualize the weather of 500+ cities across the world of varying distance from the equator. To accomplish this, you'll be utilizing a [simple Python library](https://pypi.python.org/pypi/citipy), the [OpenWeatherMap API](https://openweathermap.org/api), and a little common sense to create a representative model of weather across world cities.

Your objective is to build a series of scatter plots to showcase the following relationships:

* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude

Your final notebook must:

* Randomly select **at least** 500 unique (non-repeat) cities based on latitude and longitude.
* Perform a weather check on each of the cities using a series of successive API calls. 
* Include a print log of each city as it's being processed with the city number, city name, and requested URL.
* Save both a CSV of all data retrieved and png images for each scatter plot.

As final considerations:

* You must use the Matplotlib and Seaborn libraries.
* You must include a written description of three observable trends based on the data. 
* You must use proper labeling of your plots, including aspects like: Plot Titles (with date of analysis) and Axes Labels.
* You must include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  
* See [Example Solution](WeatherPy_Example.pdf) for a reference on expected format. 

## Hints and Considerations

* You may want to start this assignment by refreshing yourself on 4th grade geography, in particular, the [geographic coordinate system](http://desktop.arcgis.com/en/arcmap/10.3/guide-books/map-projections/about-geographic-coordinate-systems.htm). 

* Next, spend the requisite time necessary to study the OpenWeatherMap API. Based on your initial study, you should be able to answer  basic questions about the API: Where do you request the API key? Which Weather API in particular will you need? What URL endpoints does it expect? What JSON structure does it respond with? Before you write a line of code, you should be aiming to have a crystal clear understanding of your intended outcome.

* Though we've never worked with the [citipy Python library](https://pypi.python.org/pypi/citipy), push yourself to decipher how it works, and why it might be relevant. Before you try to incorporate the library into your analysis, start by creating simple test cases outside your main script to confirm that you are using it correctly. Too often, when introduced to a new library, students get bogged down by the most minor of errors -- spending hours investigating their entire code -- when, in fact, a simple and focused test would have shown their basic utilization of the library was wrong from the start. Don't let this be you!

* Part of our expectation in this challenge is that you will use critical thinking skills to understand how and why we're recommending the tools we are. What is Citipy for? Why would you use it in conjunction with the OpenWeatherMap API? How would you do so?

* In building your script, pay attention to the cities you are using in your query pool. Are you getting coverage of the full gamut of latitudes and longitudes? Or are you simply choosing 500 cities concentrated in one region of the world? Even if you were a geographic genius, simply rattling 500 cities based on your human selection would create a biased dataset. Be thinking of how you should counter this. (Hint: Consider the full range of latitudes).

* Lastly, remember -- this is a challenging activity. Push yourself! If you complete this task, then you can safely say that you've gained a strong mastery of the core foundations of data analytics and it will only go better from here. Good luck!

## Copyright

Coding Boot Camp (C) 2016. All Rights Reserved.

<h1>WeatherPy</h1>
<h2>Analysis</h2>
<ul>
    <li>The temperature for the tropical regions between the Tropic of Cancer and Tropic of Capricorn are warm, with temperatures between 60 and 100 Fahrenheit.  In the temperate zone north of the Tropic of Cancer, the temperature is colder as you approach the Arctic Circle.  This does not occur in the southern hemisphere because this area is mostly ocean.
</li>
    <li>For March 13, 2018, the temperature at the University of Southern California was between 60 and 70 Fahrenheit.  This is consistent for being in a temperate zone but closer to the Tropic of Cancer than the Arctic Circle.</li>
    <li>The warmest temperature was between the Equator and Tropic of Cancer at about 105 Fahrenheit.  The coldest temperatures where below -30 Fahrenheit near the Arctic Circle.</li>
</ul>


```python
# Dependencies
import json
import requests
import pandas as pd
import csv
import random
import matplotlib.pyplot as plt
import numpy as np
import config
import datetime
import time
```

    <class 'list'>
    

<h2>Generate Cities List</h2>


```python
# Create a reference the CSV file desired
csv_path = "worldcities.csv"

# Read the CSV into a Pandas DataFrame
df = pd.read_csv(csv_path)

# Print the first five rows of data to the screen
df.head()

df = df.dropna(how="any")

df.count()
```




    Country      46831
    City         46831
    Latitude     46831
    Longitude    46831
    dtype: int64




```python
# Randomly select city names.
city_list = list(df.loc[:,'City'])

random_cities = random.sample(city_list, 2000)

random_cities.insert(0, 'los angeles') # Get the weather for USC.

# print(json.dumps(random_cities, indent=4, sort_keys=True))
```

<h2>Perform API Calls</h2>


```python
# Get random weather.
    
accepted_records = 0
    
random_weathers = {}

city_limit = 600
    
url = "http://api.openweathermap.org/data/2.5/weather?"
    
api_keys = config.api_keys
api_index = 0


    
for city_name in random_cities:

    random_weather = {}
    
    query_url = "{0}appid={1}&q={2}&units=imperial".format(url,api_keys[api_index],city_name)

    weather_response = None

    weather_response = requests.get(query_url)
    
    if weather_response is None:
        print("Request returned nothing.  Changing API key.")
        api_index = api_index + 1
        continue

    if weather_response.status_code == 404:
        print('\n404', city_name, "was not found.", "\n", query_url)
        continue
    weather_json = weather_response.json()
    
    if weather_response.status_code == 200:
        pass
    else:
        print("Unexpected status code:", str(weather_response.status_code))

    try:
        if city_name == weather_json.get('name').lower():
            pass
        else:
            print("city_name ", city_name, "did not match", weather_json.get('name').lower())
            break
            
        random_weather['Max Temp'] = weather_json.get('main').get('temp_max')
        random_weather['Humidity'] = weather_json.get('main').get('humidity')
        random_weather['Lng'] = weather_json.get('coord').get('lon')
        random_weather['Lat'] = weather_json.get('coord').get('lat')
        random_weather['Date'] = str(weather_json.get('dt'))
        random_weather['Cloudiness'] = weather_json.get('clouds').get('all')
        random_weather['Country'] = weather_json.get('sys').get('country')
        random_weather['Wind Speed'] = weather_json.get('wind').get('speed')
        accepted_records = accepted_records + 1
        print("\n", str(weather_response.status_code), str(accepted_records), city_name, "\n", query_url)
        random_weathers[city_name] = random_weather
        if accepted_records >= city_limit:
            break

    except AttributeError:
        print(city_name, "had an AttributeError")
        continue   
        
```

    
     200 1 los angeles 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=los angeles&units=imperial
    
     200 2 sankt jakob 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sankt jakob&units=imperial
    
     200 3 dalsingh sarai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dalsingh sarai&units=imperial
    
     200 4 sar-e pul 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sar-e pul&units=imperial
    
    404 unye was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=unye&units=imperial
    
     200 5 liti 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=liti&units=imperial
    
     200 6 garanhuns 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=garanhuns&units=imperial
    
     200 7 domont 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=domont&units=imperial
    
     200 8 namli 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=namli&units=imperial
    
     200 9 tlacotepec 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tlacotepec&units=imperial
    
     200 10 fujimi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fujimi&units=imperial
    
     200 11 bernardino de campos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bernardino de campos&units=imperial
    
     200 12 desnogorsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=desnogorsk&units=imperial
    
     200 13 herstal 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=herstal&units=imperial
    
     200 14 ulan-ude 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ulan-ude&units=imperial
    
     200 15 bela 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bela&units=imperial
    
     200 16 tianmen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tianmen&units=imperial
    
     200 17 neftegorsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=neftegorsk&units=imperial
    
     200 18 braganca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=braganca&units=imperial
    
     200 19 katumba 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=katumba&units=imperial
    
     200 20 revadanda 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=revadanda&units=imperial
    
     200 21 alexandria 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alexandria&units=imperial
    
     200 22 kankakee 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kankakee&units=imperial
    
     200 23 bhabua 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bhabua&units=imperial
    
     200 24 korostyshiv 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=korostyshiv&units=imperial
    
     200 25 komadi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=komadi&units=imperial
    
     200 26 zebbug 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zebbug&units=imperial
    
     200 27 bangad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bangad&units=imperial
    
     200 28 petrovaradin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=petrovaradin&units=imperial
    
     200 29 mardan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mardan&units=imperial
    
     200 30 maibong 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=maibong&units=imperial
    
     200 31 doudleby nad orlici 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=doudleby nad orlici&units=imperial
    
     200 32 borsice 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=borsice&units=imperial
    
     200 33 negrar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=negrar&units=imperial
    
     200 34 mesesenii de jos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mesesenii de jos&units=imperial
    
     200 35 cobh 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cobh&units=imperial
    
     200 36 morfelden-walldorf 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=morfelden-walldorf&units=imperial
    
     200 37 baikunthpur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=baikunthpur&units=imperial
    
     200 38 puerto caimito 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=puerto caimito&units=imperial
    
     200 39 landau 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=landau&units=imperial
    
     200 40 sehnde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sehnde&units=imperial
    
     200 41 voskresensk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=voskresensk&units=imperial
    
     200 42 niltepec 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=niltepec&units=imperial
    
     200 43 metapan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=metapan&units=imperial
    
     200 44 viile satu mare 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=viile satu mare&units=imperial
    
     200 45 san luis jilotepeque 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san luis jilotepeque&units=imperial
    
     200 46 hohen neuendorf 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hohen neuendorf&units=imperial
    
     200 47 belas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=belas&units=imperial
    
     200 48 san antonio 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san antonio&units=imperial
    
    404 chelyabinsk-70 was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chelyabinsk-70&units=imperial
    
     200 49 tuganay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tuganay&units=imperial
    
     200 50 marataizes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=marataizes&units=imperial
    
     200 51 tewksbury 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tewksbury&units=imperial
    
     200 52 bolshaya dzhalga 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bolshaya dzhalga&units=imperial
    
     200 53 swiecie 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=swiecie&units=imperial
    
     200 54 san pedro zacapa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san pedro zacapa&units=imperial
    
     200 55 wasserbillig 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wasserbillig&units=imperial
    
     200 56 alekseyevka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alekseyevka&units=imperial
    
     200 57 bunbury 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bunbury&units=imperial
    
     200 58 garzon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=garzon&units=imperial
    
     200 59 paravur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=paravur&units=imperial
    
     200 60 san jose 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san jose&units=imperial
    
     200 61 bridgewater 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bridgewater&units=imperial
    
     200 62 yertsevo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=yertsevo&units=imperial
    
     200 63 kulgam 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kulgam&units=imperial
    
     200 64 agde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=agde&units=imperial
    
     200 65 de land 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=de land&units=imperial
    
     200 66 cernay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cernay&units=imperial
    
     200 67 sonipat 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sonipat&units=imperial
    
     200 68 quipapa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=quipapa&units=imperial
    
     200 69 schrems 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schrems&units=imperial
    
     200 70 la venta del astillero 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=la venta del astillero&units=imperial
    
     200 71 kosiv 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kosiv&units=imperial
    
     200 72 scortoasa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=scortoasa&units=imperial
    
     200 73 vastse-kuuste 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vastse-kuuste&units=imperial
    
     200 74 el cerrito 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=el cerrito&units=imperial
    
     200 75 pungesti 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pungesti&units=imperial
    
     200 76 tumsar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tumsar&units=imperial
    
     200 77 kajaani 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kajaani&units=imperial
    
     200 78 si sa ket 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=si sa ket&units=imperial
    
     200 79 caohai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=caohai&units=imperial
    
     200 80 brie-comte-robert 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=brie-comte-robert&units=imperial
    
     200 81 topola 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=topola&units=imperial
    
     200 82 huaquechula 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=huaquechula&units=imperial
    
     200 83 chinandega 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chinandega&units=imperial
    
     200 84 saint-gilles 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=saint-gilles&units=imperial
    
     200 85 alacaygan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alacaygan&units=imperial
    
     200 86 saint-martin-boulogne 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=saint-martin-boulogne&units=imperial
    
     200 87 soldanu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=soldanu&units=imperial
    
     200 88 nadbai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nadbai&units=imperial
    
     200 89 decatur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=decatur&units=imperial
    
     200 90 marano di napoli 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=marano di napoli&units=imperial
    
     200 91 cartago 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cartago&units=imperial
    
     200 92 montagnana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=montagnana&units=imperial
    
     200 93 nosivka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nosivka&units=imperial
    
     200 94 tashir 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tashir&units=imperial
    
     200 95 faridabad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=faridabad&units=imperial
    
     200 96 pena blanca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pena blanca&units=imperial
    
     200 97 choisy-le-roi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=choisy-le-roi&units=imperial
    
     200 98 ried 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ried&units=imperial
    
     200 99 iacobeni 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=iacobeni&units=imperial
    
     200 100 santa isabel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=santa isabel&units=imperial
    
     200 101 kuki 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kuki&units=imperial
    
     200 102 neftekamsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=neftekamsk&units=imperial
    
     200 103 bakaly 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bakaly&units=imperial
    
     200 104 zhemtala 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zhemtala&units=imperial
    
     200 105 qazigund 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=qazigund&units=imperial
    
     200 106 koplik 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=koplik&units=imperial
    
    404 vzmorye was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vzmorye&units=imperial
    
     200 107 echirolles 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=echirolles&units=imperial
    
     200 108 curtea de arges 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=curtea de arges&units=imperial
    
     200 109 ayia trias 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ayia trias&units=imperial
    
     200 110 cheboksary 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cheboksary&units=imperial
    
     200 111 causip 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=causip&units=imperial
    
     200 112 lagos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lagos&units=imperial
    
     200 113 lumbayao 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lumbayao&units=imperial
    
     200 114 bolivar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bolivar&units=imperial
    
     200 115 kings park 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kings park&units=imperial
    
     200 116 vetovo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vetovo&units=imperial
    
     200 117 kintampo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kintampo&units=imperial
    
     200 118 katsina 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=katsina&units=imperial
    
     200 119 sint-katelijne-waver 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sint-katelijne-waver&units=imperial
    
     200 120 gubkin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gubkin&units=imperial
    
     200 121 kamenz 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kamenz&units=imperial
    
     200 122 wharton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wharton&units=imperial
    
     200 123 araruna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=araruna&units=imperial
    
     200 124 altamira 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=altamira&units=imperial
    
     200 125 deori khas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=deori khas&units=imperial
    
     200 126 kunjah 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kunjah&units=imperial
    
     200 127 bued 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bued&units=imperial
    
     200 128 markdale 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=markdale&units=imperial
    
     200 129 bad driburg 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bad driburg&units=imperial
    
     200 130 taquarana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=taquarana&units=imperial
    
    404 new guinlo was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=new guinlo&units=imperial
    
     200 131 coatepeque 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=coatepeque&units=imperial
    
     200 132 chattanooga 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chattanooga&units=imperial
    
    404 imeni sverdlova was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=imeni sverdlova&units=imperial
    
     200 133 saurimo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=saurimo&units=imperial
    
     200 134 murashi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=murashi&units=imperial
    
     200 135 ifakara 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ifakara&units=imperial
    
     200 136 myaundzha 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=myaundzha&units=imperial
    
     200 137 orocue 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=orocue&units=imperial
    
     200 138 daurala 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=daurala&units=imperial
    
     200 139 schilde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schilde&units=imperial
    
     200 140 apomu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=apomu&units=imperial
    
     200 141 samarskoye 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=samarskoye&units=imperial
    
     200 142 itami 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=itami&units=imperial
    
     200 143 vozuca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vozuca&units=imperial
    
     200 144 gramsh 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gramsh&units=imperial
    
    404 apaxco was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=apaxco&units=imperial
    
     200 145 rodental 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rodental&units=imperial
    
     200 146 crevalcore 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=crevalcore&units=imperial
    
     200 147 vadastra 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vadastra&units=imperial
    
     200 148 cabalitian 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cabalitian&units=imperial
    
     200 149 bitag 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bitag&units=imperial
    
     200 150 ribnitz-damgarten 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ribnitz-damgarten&units=imperial
    
    404 buensuceso was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=buensuceso&units=imperial
    
     200 151 schoten 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schoten&units=imperial
    
     200 152 skegness 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=skegness&units=imperial
    
     200 153 costesti 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=costesti&units=imperial
    
    404 el wasta was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=el wasta&units=imperial
    
     200 154 kerewan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kerewan&units=imperial
    
     200 155 gouria 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gouria&units=imperial
    
     200 156 olsberg 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=olsberg&units=imperial
    
     200 157 jichisu de jos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jichisu de jos&units=imperial
    
     200 158 vamosgyork 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vamosgyork&units=imperial
    
     200 159 sankt georgen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sankt georgen&units=imperial
    
     200 160 mercedes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mercedes&units=imperial
    
     200 161 amiens 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=amiens&units=imperial
    
    404 la gaulette was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=la gaulette&units=imperial
    
     200 162 otesani 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=otesani&units=imperial
    
     200 163 verkhneyarkeyevo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=verkhneyarkeyevo&units=imperial
    
     200 164 surdila-greci 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=surdila-greci&units=imperial
    
     200 165 puente grande 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=puente grande&units=imperial
    
     200 166 kubanskiy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kubanskiy&units=imperial
    
     200 167 reckange 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=reckange&units=imperial
    
     200 168 gafanha da nazare 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gafanha da nazare&units=imperial
    
     200 169 leeton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=leeton&units=imperial
    
     200 170 loreto 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=loreto&units=imperial
    
     200 171 zhetysay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zhetysay&units=imperial
    
     200 172 gerzel-aul 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gerzel-aul&units=imperial
    
     200 173 mantsala 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mantsala&units=imperial
    
     200 174 chenghai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chenghai&units=imperial
    
     200 175 dipolo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dipolo&units=imperial
    
    404 bolonchen was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bolonchen&units=imperial
    
     200 176 sercaia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sercaia&units=imperial
    
     200 177 voyskovitsy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=voyskovitsy&units=imperial
    
     200 178 calamar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=calamar&units=imperial
    
     200 179 raisio 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=raisio&units=imperial
    
     200 180 frameries 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=frameries&units=imperial
    
     200 181 vanatori 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vanatori&units=imperial
    
     200 182 terre rouge 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=terre rouge&units=imperial
    
     200 183 chalons-en-champagne 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chalons-en-champagne&units=imperial
    
     200 184 arnia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=arnia&units=imperial
    
     200 185 sagna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sagna&units=imperial
    
     200 186 amnat charoen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=amnat charoen&units=imperial
    
     200 187 langnau 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=langnau&units=imperial
    
     200 188 loningen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=loningen&units=imperial
    
     200 189 gomba 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gomba&units=imperial
    
     200 190 ayia marina 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ayia marina&units=imperial
    
     200 191 umm kaddadah 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=umm kaddadah&units=imperial
    
     200 192 shieli 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=shieli&units=imperial
    
     200 193 vanatori 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vanatori&units=imperial
    
     200 194 tlancualpican 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tlancualpican&units=imperial
    
     200 195 nogueira da regedoura 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nogueira da regedoura&units=imperial
    
     200 196 bacnotan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bacnotan&units=imperial
    
     200 197 kawerau 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kawerau&units=imperial
    
     200 198 tettnang 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tettnang&units=imperial
    
     200 199 espoo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=espoo&units=imperial
    
     200 200 aleksandrovskaya 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aleksandrovskaya&units=imperial
    
    404 coatlinchan was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=coatlinchan&units=imperial
    
     200 201 chipurupalle 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chipurupalle&units=imperial
    
     200 202 loganville 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=loganville&units=imperial
    
     200 203 kislyakovskaya 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kislyakovskaya&units=imperial
    
     200 204 wetter 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wetter&units=imperial
    
     200 205 nago 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nago&units=imperial
    
     200 206 shakawe 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=shakawe&units=imperial
    
     200 207 waldkirchen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=waldkirchen&units=imperial
    
    404 koboldo was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=koboldo&units=imperial
    
     200 208 andippatti 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=andippatti&units=imperial
    
     200 209 finca blanco 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=finca blanco&units=imperial
    
     200 210 aksaray 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aksaray&units=imperial
    
     200 211 pando 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pando&units=imperial
    
     200 212 maribor 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=maribor&units=imperial
    
     200 213 ayrum 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ayrum&units=imperial
    
    404 tamulte was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tamulte&units=imperial
    
    404 la tajeada was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=la tajeada&units=imperial
    
     200 214 kassiopi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kassiopi&units=imperial
    
     200 215 hudson bay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hudson bay&units=imperial
    
     200 216 arevashat 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=arevashat&units=imperial
    
     200 217 kagal 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kagal&units=imperial
    
     200 218 cserszegtomaj 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cserszegtomaj&units=imperial
    
     200 219 novouralsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=novouralsk&units=imperial
    
     200 220 modrica 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=modrica&units=imperial
    
     200 221 vadu crisului 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vadu crisului&units=imperial
    
     200 222 lons-le-saunier 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lons-le-saunier&units=imperial
    
     200 223 birkeland 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=birkeland&units=imperial
    
     200 224 zavitinsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zavitinsk&units=imperial
    
     200 225 girov 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=girov&units=imperial
    
     200 226 seka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=seka&units=imperial
    
     200 227 schweinfurt 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schweinfurt&units=imperial
    
     200 228 hirtshals 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hirtshals&units=imperial
    
     200 229 paracin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=paracin&units=imperial
    
     200 230 lolotique 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lolotique&units=imperial
    
     200 231 jefferson 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jefferson&units=imperial
    
     200 232 humberto de campos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=humberto de campos&units=imperial
    
     200 233 kabul 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kabul&units=imperial
    
     200 234 dillon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dillon&units=imperial
    
     200 235 dailly 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dailly&units=imperial
    
     200 236 oia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=oia&units=imperial
    
     200 237 jarrow 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jarrow&units=imperial
    
     200 238 jalpan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jalpan&units=imperial
    
     200 239 yachihuacaltepec 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=yachihuacaltepec&units=imperial
    
     200 240 islaz 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=islaz&units=imperial
    
     200 241 challakere 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=challakere&units=imperial
    
     200 242 caledonia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=caledonia&units=imperial
    
     200 243 caceres 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=caceres&units=imperial
    
     200 244 jodhpur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jodhpur&units=imperial
    
     200 245 boyle 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=boyle&units=imperial
    
     200 246 hariana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hariana&units=imperial
    
     200 247 sahbuz 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sahbuz&units=imperial
    
     200 248 hlubocky 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hlubocky&units=imperial
    
     200 249 abut 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=abut&units=imperial
    
     200 250 badin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=badin&units=imperial
    
     200 251 salvacion 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=salvacion&units=imperial
    
     200 252 konyshevka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=konyshevka&units=imperial
    
     200 253 bodri 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bodri&units=imperial
    
     200 254 slantsy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=slantsy&units=imperial
    
     200 255 passira 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=passira&units=imperial
    
     200 256 vavatenina 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vavatenina&units=imperial
    
     200 257 bedburg 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bedburg&units=imperial
    
     200 258 chicaman 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chicaman&units=imperial
    
     200 259 cumana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cumana&units=imperial
    
     200 260 kozienice 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kozienice&units=imperial
    
     200 261 plaridel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=plaridel&units=imperial
    
     200 262 dinahican 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dinahican&units=imperial
    
     200 263 kempele 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kempele&units=imperial
    
     200 264 zabkowice slaskie 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zabkowice slaskie&units=imperial
    
     200 265 windsor 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=windsor&units=imperial
    
     200 266 la verne 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=la verne&units=imperial
    
     200 267 mechanicsville 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mechanicsville&units=imperial
    
     200 268 azur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=azur&units=imperial
    
    404 garulia was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=garulia&units=imperial
    
     200 269 mahalapye 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mahalapye&units=imperial
    
     200 270 aberchirder 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aberchirder&units=imperial
    
     200 271 erzincan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=erzincan&units=imperial
    
     200 272 ewa beach 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ewa beach&units=imperial
    
     200 273 aulnay-sous-bois 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aulnay-sous-bois&units=imperial
    
     200 274 svebolle 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=svebolle&units=imperial
    
     200 275 velur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=velur&units=imperial
    
     200 276 boksitogorsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=boksitogorsk&units=imperial
    
     200 277 patna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=patna&units=imperial
    
     200 278 taunsa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=taunsa&units=imperial
    
     200 279 csaszartoltes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=csaszartoltes&units=imperial
    
     200 280 babrala 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=babrala&units=imperial
    
    404 magui was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=magui&units=imperial
    
     200 281 santa anita 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=santa anita&units=imperial
    
     200 282 tiruttani 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tiruttani&units=imperial
    
     200 283 singarayakonda 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=singarayakonda&units=imperial
    
     200 284 houffalize 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=houffalize&units=imperial
    
     200 285 grobenzell 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=grobenzell&units=imperial
    
     200 286 chojnow 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chojnow&units=imperial
    
     200 287 cuyahoga falls 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cuyahoga falls&units=imperial
    
     200 288 puerto santander 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=puerto santander&units=imperial
    
     200 289 dedovichi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dedovichi&units=imperial
    
     200 290 umaria 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=umaria&units=imperial
    
     200 291 stephenville 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=stephenville&units=imperial
    
     200 292 de bilt 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=de bilt&units=imperial
    
     200 293 kuressaare 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kuressaare&units=imperial
    
     200 294 kisangani 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kisangani&units=imperial
    
     200 295 orotina 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=orotina&units=imperial
    
     200 296 lang suan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lang suan&units=imperial
    
     200 297 tisnov 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tisnov&units=imperial
    
     200 298 kedrovyy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kedrovyy&units=imperial
    
     200 299 lamtah 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lamtah&units=imperial
    
     200 300 sabana de torres 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sabana de torres&units=imperial
    
     200 301 aldenhoven 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aldenhoven&units=imperial
    
     200 302 potsdam 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=potsdam&units=imperial
    
     200 303 nein 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nein&units=imperial
    
     200 304 lejre 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lejre&units=imperial
    
     200 305 le portel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=le portel&units=imperial
    
     200 306 rreshen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rreshen&units=imperial
    
     200 307 kamien pomorski 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kamien pomorski&units=imperial
    
     200 308 cisterna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cisterna&units=imperial
    
     200 309 america dourada 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=america dourada&units=imperial
    
     200 310 holboca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=holboca&units=imperial
    
     200 311 ozinki 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ozinki&units=imperial
    
     200 312 alampur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alampur&units=imperial
    
    404 yusva was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=yusva&units=imperial
    
     200 313 suita 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=suita&units=imperial
    
     200 314 pezinok 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pezinok&units=imperial
    
     200 315 seravezza 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=seravezza&units=imperial
    
     200 316 ibiuna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ibiuna&units=imperial
    
     200 317 puno 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=puno&units=imperial
    
    404 velykyy burluk was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=velykyy burluk&units=imperial
    
     200 318 seclin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=seclin&units=imperial
    
     200 319 north college hill 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=north college hill&units=imperial
    
     200 320 skala fourkas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=skala fourkas&units=imperial
    
     200 321 pensilvania 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pensilvania&units=imperial
    
     200 322 tipp city 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tipp city&units=imperial
    
     200 323 hodac 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hodac&units=imperial
    
     200 324 asbestos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=asbestos&units=imperial
    
    404 tiruvottiyur was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tiruvottiyur&units=imperial
    
     200 325 carcasi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=carcasi&units=imperial
    
    404 novoilinskiy was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=novoilinskiy&units=imperial
    
     200 326 meerane 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=meerane&units=imperial
    
     200 327 lieto 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lieto&units=imperial
    
     200 328 valparaiso 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=valparaiso&units=imperial
    
     200 329 potot 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=potot&units=imperial
    
     200 330 waitara 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=waitara&units=imperial
    
     200 331 payson 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=payson&units=imperial
    
     200 332 holoby 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=holoby&units=imperial
    
     200 333 alangilan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alangilan&units=imperial
    
     200 334 cogon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cogon&units=imperial
    
     200 335 subcetate 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=subcetate&units=imperial
    
     200 336 caba 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=caba&units=imperial
    
     200 337 union de reyes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=union de reyes&units=imperial
    
     200 338 merchtem 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=merchtem&units=imperial
    
     200 339 areia branca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=areia branca&units=imperial
    
     200 340 simcoe 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=simcoe&units=imperial
    
     200 341 veroce 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=veroce&units=imperial
    
     200 342 port hope 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=port hope&units=imperial
    
     200 343 alijis 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alijis&units=imperial
    
     200 344 bacon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bacon&units=imperial
    
     200 345 koutiala 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=koutiala&units=imperial
    
    404 sikeai was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sikeai&units=imperial
    
     200 346 dendermonde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dendermonde&units=imperial
    
     200 347 raditsa-krylovka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=raditsa-krylovka&units=imperial
    
    404 urulga was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=urulga&units=imperial
    
     200 348 ano poroia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ano poroia&units=imperial
    
     200 349 noyabrsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=noyabrsk&units=imperial
    
     200 350 santandrei 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=santandrei&units=imperial
    
     200 351 farmington 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=farmington&units=imperial
    
    404 un was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=un&units=imperial
    
     200 352 serenje 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=serenje&units=imperial
    
     200 353 kingston 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kingston&units=imperial
    
     200 354 alberton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=alberton&units=imperial
    
     200 355 cabatuan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cabatuan&units=imperial
    
     200 356 sogod 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sogod&units=imperial
    
     200 357 kholuy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kholuy&units=imperial
    
     200 358 kimry 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kimry&units=imperial
    
     200 359 rocky mount 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rocky mount&units=imperial
    
     200 360 sevsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sevsk&units=imperial
    
     200 361 bezopasnoye 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bezopasnoye&units=imperial
    
    404 ambeliai was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ambeliai&units=imperial
    
     200 362 recsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=recsk&units=imperial
    
     200 363 bakhmach 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bakhmach&units=imperial
    
     200 364 simacota 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=simacota&units=imperial
    
     200 365 cambuquira 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cambuquira&units=imperial
    
     200 366 otavi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=otavi&units=imperial
    
     200 367 trowbridge 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=trowbridge&units=imperial
    
     200 368 penalva 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=penalva&units=imperial
    
     200 369 san-pedro 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san-pedro&units=imperial
    
     200 370 darfo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=darfo&units=imperial
    
     200 371 bad munstereifel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bad munstereifel&units=imperial
    
     200 372 sinjar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sinjar&units=imperial
    
     200 373 poli 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=poli&units=imperial
    
     200 374 dukay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dukay&units=imperial
    
     200 375 khagaul 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=khagaul&units=imperial
    
     200 376 borovoy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=borovoy&units=imperial
    
     200 377 boajibu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=boajibu&units=imperial
    
     200 378 saint-vallier 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=saint-vallier&units=imperial
    
     200 379 kalaleh 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kalaleh&units=imperial
    
     200 380 brebu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=brebu&units=imperial
    
     200 381 saint petersburg 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=saint petersburg&units=imperial
    
     200 382 piliscsaba 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=piliscsaba&units=imperial
    
     200 383 netolice 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=netolice&units=imperial
    
     200 384 santa cruz de yojoa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=santa cruz de yojoa&units=imperial
    
     200 385 bugcaon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bugcaon&units=imperial
    
    404 polikastron was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=polikastron&units=imperial
    
     200 386 mizil 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mizil&units=imperial
    
     200 387 szada 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=szada&units=imperial
    
     200 388 khorol 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=khorol&units=imperial
    
     200 389 goalpara 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=goalpara&units=imperial
    
     200 390 nea santa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nea santa&units=imperial
    
     200 391 rumonge 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rumonge&units=imperial
    
    404 schlusselburg was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schlusselburg&units=imperial
    
     200 392 north las vegas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=north las vegas&units=imperial
    
     200 393 consolacion del sur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=consolacion del sur&units=imperial
    
     200 394 greiveldange 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=greiveldange&units=imperial
    
     200 395 satulung 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=satulung&units=imperial
    
    404 yian was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=yian&units=imperial
    
     200 396 laguna verde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=laguna verde&units=imperial
    
     200 397 bosilegrad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bosilegrad&units=imperial
    
     200 398 danane 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=danane&units=imperial
    
     200 399 el calvario 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=el calvario&units=imperial
    
     200 400 pueblo nuevo solistahuacan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pueblo nuevo solistahuacan&units=imperial
    
     200 401 mountrath 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mountrath&units=imperial
    
     200 402 aguada de pasajeros 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aguada de pasajeros&units=imperial
    
     200 403 ortakoy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ortakoy&units=imperial
    
    404 segalstad was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=segalstad&units=imperial
    
     200 404 radhanpur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=radhanpur&units=imperial
    
     200 405 mezinovskiy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mezinovskiy&units=imperial
    
     200 406 lessines 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lessines&units=imperial
    
     200 407 dobrokoz 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dobrokoz&units=imperial
    
     200 408 oktyabrskoye 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=oktyabrskoye&units=imperial
    
     200 409 zhavoronki 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zhavoronki&units=imperial
    
     200 410 solkan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=solkan&units=imperial
    
    404 lokken verk was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lokken verk&units=imperial
    
     200 411 lensk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lensk&units=imperial
    
     200 412 vrnograc 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vrnograc&units=imperial
    
     200 413 guru har sahai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=guru har sahai&units=imperial
    
     200 414 bang khla 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bang khla&units=imperial
    
     200 415 riyadh 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=riyadh&units=imperial
    
     200 416 banganapalle 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=banganapalle&units=imperial
    
    404 faleapuna was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=faleapuna&units=imperial
    
     200 417 rusera 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rusera&units=imperial
    
     200 418 novocheboksarsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=novocheboksarsk&units=imperial
    
     200 419 bambolim 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bambolim&units=imperial
    
     200 420 sinj 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sinj&units=imperial
    
     200 421 bois-guillaume 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bois-guillaume&units=imperial
    
     200 422 pennsville 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pennsville&units=imperial
    
     200 423 hangal 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hangal&units=imperial
    
     200 424 lodi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lodi&units=imperial
    
     200 425 fenyi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fenyi&units=imperial
    
     200 426 ujfeherto 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ujfeherto&units=imperial
    
     200 427 libertad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=libertad&units=imperial
    
     200 428 schrobenhausen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=schrobenhausen&units=imperial
    
     200 429 silale 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=silale&units=imperial
    
     200 430 ambasamudram 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ambasamudram&units=imperial
    
     200 431 charlton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=charlton&units=imperial
    
     200 432 corte madera 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=corte madera&units=imperial
    
     200 433 bahay pare 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bahay pare&units=imperial
    
    404 pengkalan kundang was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pengkalan kundang&units=imperial
    
     200 434 salamanca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=salamanca&units=imperial
    
     200 435 concepcion 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=concepcion&units=imperial
    
     200 436 mirganj 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mirganj&units=imperial
    
     200 437 hamm 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hamm&units=imperial
    
     200 438 uusikaupunki 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=uusikaupunki&units=imperial
    
     200 439 toulon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=toulon&units=imperial
    
     200 440 jubasan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jubasan&units=imperial
    
     200 441 karatsu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=karatsu&units=imperial
    
     200 442 borovskiy 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=borovskiy&units=imperial
    
     200 443 bugas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bugas&units=imperial
    
     200 444 satinka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=satinka&units=imperial
    
    404 flambouron was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=flambouron&units=imperial
    
     200 445 albesti 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=albesti&units=imperial
    
     200 446 pawing 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pawing&units=imperial
    
     200 447 nueva imperial 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nueva imperial&units=imperial
    
     200 448 san luis 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san luis&units=imperial
    
     200 449 des moines 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=des moines&units=imperial
    
    404 belize was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=belize&units=imperial
    
     200 450 shyryayeve 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=shyryayeve&units=imperial
    
     200 451 plaridel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=plaridel&units=imperial
    
     200 452 baronissi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=baronissi&units=imperial
    
     200 453 quezailica 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=quezailica&units=imperial
    
     200 454 el carrizo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=el carrizo&units=imperial
    
     200 455 aygestan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aygestan&units=imperial
    
    404 arkhaia olimbia was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=arkhaia olimbia&units=imperial
    
     200 456 wesel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wesel&units=imperial
    
    404 sapapalii was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sapapalii&units=imperial
    
     200 457 winfield 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=winfield&units=imperial
    
     200 458 uirauna 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=uirauna&units=imperial
    
     200 459 kirchbichl 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kirchbichl&units=imperial
    
     200 460 velingrad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=velingrad&units=imperial
    
     200 461 khambhaliya 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=khambhaliya&units=imperial
    
     200 462 ardatov 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ardatov&units=imperial
    
     200 463 kallifitos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kallifitos&units=imperial
    
    404 cafe was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cafe&units=imperial
    
     200 464 kurara 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kurara&units=imperial
    
    404 sperkhias was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sperkhias&units=imperial
    
    404 elasson was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=elasson&units=imperial
    
     200 465 bradenton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bradenton&units=imperial
    
     200 466 fershampenuaz 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fershampenuaz&units=imperial
    
     200 467 kolobrzeg 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kolobrzeg&units=imperial
    
     200 468 san agustin 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san agustin&units=imperial
    
     200 469 fortaleza 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fortaleza&units=imperial
    
     200 470 lake havasu city 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lake havasu city&units=imperial
    
     200 471 xiaoyi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=xiaoyi&units=imperial
    
     200 472 imeni vorovskogo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=imeni vorovskogo&units=imperial
    
     200 473 prosec 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=prosec&units=imperial
    
     200 474 kenosha 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kenosha&units=imperial
    
    404 maloshuyka was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=maloshuyka&units=imperial
    
     200 475 wrzesnia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wrzesnia&units=imperial
    
     200 476 cheran 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cheran&units=imperial
    
     200 477 burdur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=burdur&units=imperial
    
     200 478 viana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=viana&units=imperial
    
     200 479 masaya 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=masaya&units=imperial
    
     200 480 sylvan lake 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sylvan lake&units=imperial
    
     200 481 robertsonpet 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=robertsonpet&units=imperial
    
     200 482 horodenka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=horodenka&units=imperial
    
     200 483 buyo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=buyo&units=imperial
    
     200 484 freetown 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=freetown&units=imperial
    
     200 485 khatukay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=khatukay&units=imperial
    
     200 486 say 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=say&units=imperial
    
     200 487 altepexi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=altepexi&units=imperial
    
     200 488 kilvelur 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kilvelur&units=imperial
    
     200 489 jirlau 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=jirlau&units=imperial
    
     200 490 south orange 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=south orange&units=imperial
    
     200 491 kadungora 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kadungora&units=imperial
    
     200 492 hiddenhausen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hiddenhausen&units=imperial
    
     200 493 whitley bay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=whitley bay&units=imperial
    
     200 494 torrelavega 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=torrelavega&units=imperial
    
     200 495 aranjuez 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=aranjuez&units=imperial
    
     200 496 el playon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=el playon&units=imperial
    
     200 497 kokkarion 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kokkarion&units=imperial
    
     200 498 barrington 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=barrington&units=imperial
    
     200 499 sincai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sincai&units=imperial
    
     200 500 oak ridge 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=oak ridge&units=imperial
    
     200 501 breaza 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=breaza&units=imperial
    
     200 502 cedar mill 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cedar mill&units=imperial
    
     200 503 palaiokomi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=palaiokomi&units=imperial
    
     200 504 parsabad 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=parsabad&units=imperial
    
     200 505 yanacancha 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=yanacancha&units=imperial
    
     200 506 ulundi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ulundi&units=imperial
    
     200 507 resplendor 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=resplendor&units=imperial
    
     200 508 hoboken 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hoboken&units=imperial
    
     200 509 salamanca 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=salamanca&units=imperial
    
     200 510 fuyu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fuyu&units=imperial
    
     200 511 baley 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=baley&units=imperial
    
     200 512 canoas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=canoas&units=imperial
    
     200 513 denton 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=denton&units=imperial
    
     200 514 tulnici 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tulnici&units=imperial
    
     200 515 tiszakeszi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tiszakeszi&units=imperial
    
     200 516 zlonice 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zlonice&units=imperial
    
     200 517 santa vitoria do palmar 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=santa vitoria do palmar&units=imperial
    
     200 518 adancata 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=adancata&units=imperial
    
     200 519 pasco 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pasco&units=imperial
    
     200 520 baffa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=baffa&units=imperial
    
     200 521 wodonga 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=wodonga&units=imperial
    
     200 522 limbdi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=limbdi&units=imperial
    
     200 523 hrymayliv 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hrymayliv&units=imperial
    
     200 524 matabungkay 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=matabungkay&units=imperial
    
     200 525 bella vista 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bella vista&units=imperial
    
     200 526 bugsoc 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bugsoc&units=imperial
    
     200 527 gilleleje 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=gilleleje&units=imperial
    
     200 528 szabadszallas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=szabadszallas&units=imperial
    
     200 529 muggio 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=muggio&units=imperial
    
     200 530 lachhmangarh 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lachhmangarh&units=imperial
    
     200 531 milovice 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=milovice&units=imperial
    
     200 532 cervantes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cervantes&units=imperial
    
     200 533 ziyang 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ziyang&units=imperial
    
     200 534 kilrush 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kilrush&units=imperial
    
     200 535 samana 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=samana&units=imperial
    
    404 tabuan was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tabuan&units=imperial
    
     200 536 nizhniy odes 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nizhniy odes&units=imperial
    
     200 537 ramenskoye 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ramenskoye&units=imperial
    
     200 538 nowa sol 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nowa sol&units=imperial
    
     200 539 muborak 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=muborak&units=imperial
    
     200 540 sorgun 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sorgun&units=imperial
    
     200 541 nadigaon 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nadigaon&units=imperial
    
     200 542 askino 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=askino&units=imperial
    
     200 543 muslyumovo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=muslyumovo&units=imperial
    
     200 544 mahmudia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mahmudia&units=imperial
    
     200 545 sarukhan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sarukhan&units=imperial
    
     200 546 tuglui 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tuglui&units=imperial
    
     200 547 vossevangen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=vossevangen&units=imperial
    
     200 548 kutna hora 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kutna hora&units=imperial
    
     200 549 chalmette 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chalmette&units=imperial
    
     200 550 san enrique 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=san enrique&units=imperial
    
     200 551 catio 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=catio&units=imperial
    
     200 552 kunda 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kunda&units=imperial
    
     200 553 rheda-wiedenbruck 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rheda-wiedenbruck&units=imperial
    
     200 554 kwekwe 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kwekwe&units=imperial
    
     200 555 balibago 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=balibago&units=imperial
    
     200 556 kumeny 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kumeny&units=imperial
    
     200 557 sakit 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sakit&units=imperial
    
     200 558 oyo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=oyo&units=imperial
    
     200 559 zyukayka 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zyukayka&units=imperial
    
     200 560 goyty 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=goyty&units=imperial
    
     200 561 fayetteville 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=fayetteville&units=imperial
    
     200 562 lubawa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lubawa&units=imperial
    
     200 563 muskego 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=muskego&units=imperial
    
     200 564 dok kham tai 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dok kham tai&units=imperial
    
     200 565 murray 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=murray&units=imperial
    
     200 566 roxas 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=roxas&units=imperial
    
     200 567 ferreiras 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ferreiras&units=imperial
    
     200 568 bhopal 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bhopal&units=imperial
    
     200 569 khorinsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=khorinsk&units=imperial
    
    404 oshogbo was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=oshogbo&units=imperial
    
     200 570 rubtsovsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=rubtsovsk&units=imperial
    
     200 571 ano lekhonia 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=ano lekhonia&units=imperial
    
     200 572 cleveland heights 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=cleveland heights&units=imperial
    
     200 573 tselina 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=tselina&units=imperial
    
     200 574 lawang 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lawang&units=imperial
    
     200 575 mangaldan 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=mangaldan&units=imperial
    
     200 576 forio 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=forio&units=imperial
    
     200 577 kashmor 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kashmor&units=imperial
    
     200 578 havant 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=havant&units=imperial
    
     200 579 bad wildungen 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bad wildungen&units=imperial
    
     200 580 southglenn 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=southglenn&units=imperial
    
     200 581 chengde 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=chengde&units=imperial
    
     200 582 dapa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=dapa&units=imperial
    
     200 583 kencong 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=kencong&units=imperial
    
     200 584 nhlangano 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nhlangano&units=imperial
    
     200 585 hoskote 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=hoskote&units=imperial
    
     200 586 sukabumi 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sukabumi&units=imperial
    
    404 xirokambos was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=xirokambos&units=imperial
    
     200 587 burgos 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=burgos&units=imperial
    
     200 588 volgorechensk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=volgorechensk&units=imperial
    
     200 589 pietroasa 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pietroasa&units=imperial
    
    404 bolshoye polpino was not found. 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=bolshoye polpino&units=imperial
    
     200 590 guspini 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=guspini&units=imperial
    
     200 591 monte carmelo 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=monte carmelo&units=imperial
    
     200 592 pundong 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=pundong&units=imperial
    
     200 593 delray beach 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=delray beach&units=imperial
    
     200 594 lebork 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=lebork&units=imperial
    
     200 595 akersberga 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=akersberga&units=imperial
    
     200 596 sieu 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=sieu&units=imperial
    
     200 597 nanao 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=nanao&units=imperial
    
     200 598 talakag 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=talakag&units=imperial
    
     200 599 zelenogradsk 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=zelenogradsk&units=imperial
    
     200 600 stiring-wendel 
     http://api.openweathermap.org/data/2.5/weather?appid=58ed8ba18463655361304e30941eebf0&q=stiring-wendel&units=imperial
    


```python
# Tabulate the random weather.
df_weather = pd.DataFrame(random_weathers)

# Move the city to the row index.
df_weather = df_weather.T

# Move the city index to a column.
df_weather = df_weather.reset_index()

# Rename the index column to city
df_weather = df_weather.rename(columns={"index":"City"})


# Show first five rows.
df_weather.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Country</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Lat</th>
      <th>Lng</th>
      <th>Max Temp</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>aberchirder</td>
      <td>75</td>
      <td>GB</td>
      <td>1520952600</td>
      <td>98</td>
      <td>57.56</td>
      <td>-2.62</td>
      <td>44.6</td>
      <td>11.41</td>
    </tr>
    <tr>
      <th>1</th>
      <td>abut</td>
      <td>68</td>
      <td>PH</td>
      <td>1520955613</td>
      <td>80</td>
      <td>16.65</td>
      <td>120.37</td>
      <td>67.81</td>
      <td>1.81</td>
    </tr>
    <tr>
      <th>2</th>
      <td>adancata</td>
      <td>75</td>
      <td>RO</td>
      <td>1520953200</td>
      <td>100</td>
      <td>47.73</td>
      <td>26.3</td>
      <td>42.8</td>
      <td>6.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>agde</td>
      <td>0</td>
      <td>FR</td>
      <td>1520951400</td>
      <td>38</td>
      <td>43.31</td>
      <td>3.47</td>
      <td>62.6</td>
      <td>9.17</td>
    </tr>
    <tr>
      <th>4</th>
      <td>aguada de pasajeros</td>
      <td>40</td>
      <td>CU</td>
      <td>1520952600</td>
      <td>64</td>
      <td>22.38</td>
      <td>-80.85</td>
      <td>75.2</td>
      <td>11.41</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Write weather dataframe to csv file.
df_weather.to_csv("random_weather.csv")
```


```python
# Start and end dates.
min_date = df_weather['Date'].min()
min_date_str = datetime.datetime.fromtimestamp(int(min_date)).strftime('%Y-%m-%d')

max_date = df_weather['Date'].max()
max_date_str = datetime.datetime.fromtimestamp(int(max_date)).strftime('%Y-%m-%d')

if (min_date_str == max_date_str):
    date_str = min_date_str
else:
    date_str = "{0} through {1}".format(min_date_str, max_date_str)
    
print(date_str)
```

    2018-03-13
    


```python
# University of Southern California
USC = {}

url = "http://api.openweathermap.org/data/2.5/weather?"

city_name = "los angeles"
country_code = "US"

query_url = "{0}appid={1}&q={2},{3}&units=imperial".format(url, api_keys[5], city_name, country_code)

weather_response = requests.get(query_url)

weather_json = weather_response.json()
    
try:
    USC['Max Temp'] = weather_json.get('main').get('temp_max')
    USC['Humidity'] = weather_json.get('main').get('humidity')
    USC['Lng'] = weather_json.get('coord').get('lon')
    USC['Lat'] = weather_json.get('coord').get('lat')
    USC['Date'] = str(weather_json.get('dt'))
    USC['Cloudiness'] = weather_json.get('clouds').get('all')
    USC['Country'] = weather_json.get('sys').get('country')
    USC['Wind Speed'] = weather_json.get('wind').get('speed')
except AttributeError:
    print(city_name, "was rejected. #############################")
    
print(json.dumps(USC, indent=4, sort_keys=True))       
```

    {
        "Cloudiness": 90,
        "Country": "US",
        "Date": "1520953440",
        "Humidity": 82,
        "Lat": 34.05,
        "Lng": -118.24,
        "Max Temp": 60.8,
        "Wind Speed": 0.47
    }
    

<h2>Latitude vs Temperature Plot</h2>


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Max Temp'])
plt.scatter(x_axis, y_axis)

# Format axis
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-30,130,10))

# Format labels
plt.xlabel('Latitude')
plt.ylabel('Max Temperature (F)')
plt.title('City Latitude vs. Max Temperature (' + date_str + ')')


# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)  
vertical_location = -44
plt.text(65.5,vertical_location, 'Artic Circle', rotation=90)
plt.text(22.5,vertical_location, 'Tropic of Cancer', rotation=90)
plt.text(-0.5,vertical_location, 'Equator       ', rotation=90)
plt.text(-23.5,vertical_location, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5,vertical_location, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, vertical_location, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Max Temp'), color='red')
plt.text(-95, USC.get('Max Temp') -0.1, 'USC', color='red')


plt.show()
```


![png](output_13_0.png)


<h2>Latitude vs. Humidity Plot


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Humidity'])
plt.scatter(x_axis, y_axis)

# Format axis.
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 110, 10))

# Add labels
plt.xlabel('Latitude')
plt.ylabel('Humidity')
plt.title('City Latitude vs. Humidity (' + date_str + ')')



# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5,-15, 'Artic Circle', rotation=90)
plt.text(22.5,-15, 'Tropic of Cancer', rotation=90)
plt.text(-0.5,-15, 'Equator       ', rotation=90)
plt.text(-23.5,-15, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5,-15, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -15, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Humidity'), color='red')
plt.text(-95, USC.get('Humidity') -0.1, 'USC', color='red')


plt.show()
```


![png](output_15_0.png)


<h2>Latitude vs. Cloudiness Plot</h2>


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Cloudiness'])
plt.scatter(x_axis, y_axis)

# Format axis.
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 110, 10))

# Add labels
plt.xlabel('Latitude')
plt.ylabel('Cloudiness')
plt.title('City Latitude vs. Cloudiness (' + date_str + ')')

# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5, -15, 'Artic Circle', rotation=90)
plt.text(22.5, -15, 'Tropic of Cancer', rotation=90)
plt.text(-0.5, -15, 'Equator       ', rotation=90)
plt.text(-23.5, -15, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5, -15, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -15, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Cloudiness'), color='red')
plt.text(-95, USC.get('Cloudiness') -0.1, 'USC', color='red')


plt.show()
```


![png](output_17_0.png)


<h2>Latitude vs. Wind Speed Plot


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Wind Speed'])
plt.scatter(x_axis, y_axis)

# Format axis
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 50, 10))

plt.xlabel('Latitude')
plt.ylabel('Wind Speed (MPH)')
plt.title('City Latitude vs. Wind Speed (' + date_str + ')')


# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5, -12, 'Artic Circle', rotation=90)
plt.text(22.5, -12, 'Tropic of Cancer', rotation=90)
plt.text(-0.5, -12, 'Equator       ', rotation=90)
plt.text(-23.5, -12, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5, -12, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -12, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Wind Speed'), color='red')
plt.text(-95, USC.get('Wind Speed') -0.1, 'USC', color='red')


plt.show()
```


![png](output_19_0.png)



## Unit 6 | Assignment - What's the Weather Like?

## Background

Whether financial, political, or social -- data's true power lies in its ability to answer questions definitively. So let's take what you've learned about Python requests, APIs, and JSON traversals to answer a fundamental question: "What's the weather like as we approach the equator?"

Now, we know what you may be thinking: _"Duh. It gets hotter..."_ 

But, if pressed, how would you **prove** it? 

![Equator](equatorsign.png)

## WeatherPy

In this example, you'll be creating a Python script to visualize the weather of 500+ cities across the world of varying distance from the equator. To accomplish this, you'll be utilizing a [simple Python library](https://pypi.python.org/pypi/citipy), the [OpenWeatherMap API](https://openweathermap.org/api), and a little common sense to create a representative model of weather across world cities.

Your objective is to build a series of scatter plots to showcase the following relationships:

* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude

Your final notebook must:

* Randomly select **at least** 500 unique (non-repeat) cities based on latitude and longitude.
* Perform a weather check on each of the cities using a series of successive API calls. 
* Include a print log of each city as it's being processed with the city number, city name, and requested URL.
* Save both a CSV of all data retrieved and png images for each scatter plot.

As final considerations:

* You must use the Matplotlib and Seaborn libraries.
* You must include a written description of three observable trends based on the data. 
* You must use proper labeling of your plots, including aspects like: Plot Titles (with date of analysis) and Axes Labels.
* You must include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  
* See [Example Solution](WeatherPy_Example.pdf) for a reference on expected format. 

## Hints and Considerations

* You may want to start this assignment by refreshing yourself on 4th grade geography, in particular, the [geographic coordinate system](http://desktop.arcgis.com/en/arcmap/10.3/guide-books/map-projections/about-geographic-coordinate-systems.htm). 

* Next, spend the requisite time necessary to study the OpenWeatherMap API. Based on your initial study, you should be able to answer  basic questions about the API: Where do you request the API key? Which Weather API in particular will you need? What URL endpoints does it expect? What JSON structure does it respond with? Before you write a line of code, you should be aiming to have a crystal clear understanding of your intended outcome.

* Though we've never worked with the [citipy Python library](https://pypi.python.org/pypi/citipy), push yourself to decipher how it works, and why it might be relevant. Before you try to incorporate the library into your analysis, start by creating simple test cases outside your main script to confirm that you are using it correctly. Too often, when introduced to a new library, students get bogged down by the most minor of errors -- spending hours investigating their entire code -- when, in fact, a simple and focused test would have shown their basic utilization of the library was wrong from the start. Don't let this be you!

* Part of our expectation in this challenge is that you will use critical thinking skills to understand how and why we're recommending the tools we are. What is Citipy for? Why would you use it in conjunction with the OpenWeatherMap API? How would you do so?

* In building your script, pay attention to the cities you are using in your query pool. Are you getting coverage of the full gamut of latitudes and longitudes? Or are you simply choosing 500 cities concentrated in one region of the world? Even if you were a geographic genius, simply rattling 500 cities based on your human selection would create a biased dataset. Be thinking of how you should counter this. (Hint: Consider the full range of latitudes).

* Lastly, remember -- this is a challenging activity. Push yourself! If you complete this task, then you can safely say that you've gained a strong mastery of the core foundations of data analytics and it will only go better from here. Good luck!

## Copyright

Coding Boot Camp (C) 2016. All Rights Reserved.

<h1>WeatherPy</h1>
<h2>Analysis</h2>
<ul>
    <li>The temperature for the tropical regions between the Tropic of Cancer and Tropic of Capricorn are warm, with temperatures between 80 and 100 Fahrenheit.  In the temperate zone north of the Tropic of Cancer, the temperature is colder as you approach the Arctic Circle.  This does not occur in the southern hemisphere because this area is mostly ocean.
</li>
    <li>For March 12, 2018, the temperature at the University of Southern California was between 70 and 80 Fahrenheit.  This is consistent for being in a temperate zone but closer to the Tropic of Cancer than the Arctic Circle.</li>
    <li>The warmest temperature was between the Equator and Tropic of Cancer at about 105 Fahrenheit.  The coldest temperatures where below -20 Fahrenheit near the Arctic Circle.</li>
</ul>


```python
# Dependencies
import json
import requests
import pandas as pd
import csv
import random
import matplotlib.pyplot as plt
import numpy as np
import config
import datetime
import time
```

<h2>Generate Cities List</h2>


```python
# Create a reference the CSV file desired
csv_path = "worldcities.csv"

# Read the CSV into a Pandas DataFrame
df = pd.read_csv(csv_path)

# Print the first five rows of data to the screen
df.head()

df = df.dropna(how="any")

df.count()
```




    Country      46831
    City         46831
    Latitude     46831
    Longitude    46831
    dtype: int64




```python
# Randomly select city names.
city_list = list(df.loc[:,'City'])

random_cities = random.sample(city_list, 2000)

random_cities.insert(0, 'los angeles') # Get the weather for USC.

# print(json.dumps(random_cities, indent=4, sort_keys=True))
```

<h2>Perform API Calls</h2>


```python
# Get random weather.
    
accepted_records = 0
    
random_weathers = {}

city_limit = 1001
    
url = "http://api.openweathermap.org/data/2.5/weather?"
    
api_keys = config.api_keys

for api_key in api_keys:
    
    if accepted_records > city_limit:
        break
    
    for city_name in random_cities:
        
        random_weather = {}
        
        query_url = "{0}appid={1}&q={2}&units=imperial".format(url,api_key,city_name)
        
        weather_response = requests.get(query_url)
        if weather_response.status_code == 404:
            print(city_name, "was not found.")
            continue
        weather_json = weather_response.json()
    
        try:
            random_weather['Max Temp'] = weather_json.get('main').get('temp_max')
            random_weather['Humidity'] = weather_json.get('main').get('humidity')
            random_weather['Lng'] = weather_json.get('coord').get('lon')
            random_weather['Lat'] = weather_json.get('coord').get('lat')
            random_weather['Date'] = str(weather_json.get('dt'))
            random_weather['Cloudiness'] = weather_json.get('clouds').get('all')
            random_weather['Country'] = weather_json.get('sys').get('country')
            random_weather['Wind Speed'] = weather_json.get('wind').get('speed')
            accepted_records = accepted_records + 1
            print(str(accepted_records), city_name)
            random_weathers[city_name] = random_weather
            if accepted_records >= city_limit:
                break
            
        except AttributeError:
            print(city_name, "had an AttributeError")
            continue     
```

    1 los angeles
    guljanci was not found.
    2 bovolone
    3 ettaiyapuram
    4 bam
    5 balintore
    6 quibdo
    7 semut
    8 opol
    9 castrillon
    10 demyanovo
    11 tulsipur
    12 hilter
    13 giulvaz
    14 saysain
    15 aknalich
    16 nova vodolaha
    17 bambolim
    18 staraya
    19 moroeni
    20 torata
    21 bellegarde-sur-valserine
    22 petit goave
    23 frata
    24 yekaterinoslavka
    25 erlenbach
    26 montelupo fiorentino
    27 galia
    28 hisai
    29 nuevo san carlos
    30 jobner
    31 legnago
    32 keansburg
    33 soquel
    34 kemri
    35 liancheng
    36 gadsden
    37 stockelsdorf
    38 cloppenburg
    39 sainte-adele
    40 baybay
    sasca montana was not found.
    41 babag
    maugat was not found.
    42 novosheshminsk
    43 nyircsaholy
    44 costa mesa
    45 nazare da mata
    46 kapelle-op-den-bos
    47 biri
    48 bang racham
    49 dhoraji
    50 west palm beach
    51 alangilanan
    52 ayios thomas
    53 krishnarajasagara
    54 pacureti
    55 agucadoura
    56 palm beach gardens
    57 ventimiglia
    58 backi petrovac
    59 riwaka
    60 ghazipur
    61 kobe
    62 thakurganj
    63 tha chang
    64 bokaa
    65 newry
    66 poopo
    67 vila real
    68 limekilns
    69 vama
    70 vokhtoga
    71 san luis
    72 zhadovka
    73 covington
    74 san remigio
    jakoruda was not found.
    75 plopii slavitesti
    76 san carlos
    77 marghita
    78 yachihuacaltepec
    79 znojmo
    80 lumil
    81 guna
    khiliomodion was not found.
    meerzorg was not found.
    82 hasuda
    83 murrhardt
    84 jagdalpur
    85 nalchik
    86 tapachula
    87 vallecillo
    88 chamonix-mont-blanc
    89 macherla
    90 medvezhyegorsk
    91 malasin
    perakhora was not found.
    92 erenhot
    93 moron de la frontera
    94 hohoe
    95 nandi
    96 bulanon
    97 pesqueria
    itum-kale was not found.
    98 nikolskoye
    99 sovetsk
    100 jawad
    101 rochester
    102 kalofer
    103 novokayakent
    104 narauli
    105 paramonga
    106 sombrio
    107 santa teresa
    108 salima
    109 tlalnepantla
    110 malitubog
    111 bessonovka
    112 rubizhne
    113 manhattan
    114 gubakha
    115 kawalu
    116 itupeva
    117 galicea
    118 batala
    119 madocsa
    120 oudenaarde
    121 silawit
    122 palm springs
    123 bridge of weir
    124 kharitonovo
    125 indiaroba
    126 zivinice
    127 adil-yangiyurt
    128 bongaigaon
    129 petropavlovskoye
    130 puurs
    131 ternovskaya
    132 feldioara
    133 krasna lipa
    134 ottawa
    135 hollabrunn
    136 karatsu
    137 manasa
    138 snyatyn
    139 orzesze
    140 tazlau
    kilakarai was not found.
    141 pong
    142 curug
    143 isahaya
    144 chiesd
    145 yerkoy
    146 gvardeyskoye
    gimangpang was not found.
    147 krasnaya polyana
    148 san juan de arama
    149 trnava
    150 pioner
    151 oleksandrivka
    152 agrafa
    153 tabalosos
    154 neverkino
    cambyreta was not found.
    155 inhumas
    156 limbiate
    157 sao francisco do conde
    158 mazagao
    159 quattro castella
    160 vyyezdnoye
    161 brno
    162 poste de flacq
    163 chaudfontaine
    164 lat yao
    165 piliscsaba
    166 jhelum
    167 warragul
    168 faruka
    169 mongomo
    170 braco do norte
    171 oktyabrskoye
    172 atkinson
    173 muthill
    174 sumiswald
    175 murnau
    176 caracal
    177 calarasi
    strendur was not found.
    178 gopalur
    179 alicia
    180 reckange
    181 maunabo
    182 pengcheng
    183 tonneins
    184 numaligarh
    185 zelzate
    186 ghoti
    187 osinovo
    188 saint john
    189 rockford
    190 volodarka
    191 bakersfield
    192 zaritap
    193 kozlovka
    194 victoria
    195 east riverdale
    196 cintalapa
    cuyutlan was not found.
    197 skala fourkas
    198 marcali
    199 lamballe
    200 talisayan
    201 sohag
    202 de haan
    203 aliso viejo
    204 bogatoye
    205 nizami
    206 sarulesti
    207 nejdek
    208 szany
    209 rosneath
    210 devgarh
    211 marshall
    212 kota
    213 stefesti
    214 rediu
    215 nea artaki
    216 lososina
    217 kysyl-syr
    218 tewksbury
    219 livenka
    220 lewisburg
    221 kawhia
    222 kato lekhonia
    223 mori
    224 molina
    225 karlivka
    226 port stanley
    227 ugento
    228 george
    229 dowa
    230 puerto lleras
    231 nipawin
    232 bogata
    233 ordubad
    234 concordia
    235 tambau
    236 huntsville
    237 tyldesley
    238 caxias do sul
    239 daud khel
    240 melilla
    241 zandak
    242 radzionkow
    243 taki
    244 spoltore
    245 patnongon
    246 pokrovo-prigorodnoye
    247 craciunesti
    248 rizia
    249 vitina
    250 pessac
    251 bagar
    252 ohrid
    uk was not found.
    253 damara
    254 sint-laureins
    255 hormigueros
    256 gava
    257 east bridgewater
    258 tlanepantla
    259 gabi
    260 putna
    261 krasnokamensk
    262 frydlant
    263 mayakonda
    264 zaozerne
    265 compiegne
    266 quinchia
    267 khatra
    268 langenlois
    269 merk
    270 mayskiy
    271 union city
    272 zdzieszowice
    273 noginsk
    274 zarubino
    275 maxcanu
    276 sayville
    277 belogorsk
    laguindingan was not found.
    278 aguia branca
    279 nova bystrice
    blackmans was not found.
    280 maxingal
    281 pijijiapan
    282 haljala
    283 san jose
    284 koutselion
    285 imperial
    286 san pedro pinula
    287 prince albert
    288 karacabey
    289 parian dakula
    290 candoso
    291 bedesa
    292 gujan-mestras
    293 burlington
    294 susanville
    295 pratapgarh
    296 amriswil
    297 fexhe-le-haut-clocher
    298 shugurovo
    299 yanji
    300 dhamtari
    301 aleksandrow kujawski
    302 johor bahru
    303 sonoma
    304 sanming
    305 tarumovka
    306 san manuel
    307 novopokrovskaya
    308 arzachena
    309 west little river
    310 bara
    311 pavlovskiy
    312 munai
    313 san francisco de cones
    314 chiusi
    saint-pacome was not found.
    315 bacabal
    316 espelkamp
    317 siraha
    318 doka
    319 canaway
    320 balahovit
    321 zonguldak
    322 smolenka
    kariotissa was not found.
    323 concepcion
    324 tha rua
    325 borgo san lorenzo
    326 dobanovci
    327 oria
    328 camopi
    329 sharon
    330 mosquera
    331 lampazos de naranjo
    332 roura
    333 nosy varika
    334 astorga
    335 wenzhou
    336 tayginka
    337 pimpri
    338 portland
    lidorikion was not found.
    339 takaungu
    340 montfermeil
    341 malu cu flori
    342 aria
    343 twin falls
    344 jiquilisco
    345 watauga
    telixtlahuaca was not found.
    346 nezlobnaya
    347 perama
    348 tariba
    349 new agutaya
    350 zopilotepe
    351 wachtberg
    352 bagheria
    353 tapiosag
    354 puerto salgar
    355 trn
    356 catalao
    357 bocsig
    bengkalis was not found.
    358 cenon
    359 gitega
    360 tatarskaya pishlya
    361 forest lake
    362 gasa
    363 moriyama
    364 pentalofos
    365 kizel
    366 meiningen
    367 dumraon
    368 mandya
    369 imst
    370 toyoake
    371 bedum
    372 petropavl
    373 urbana
    374 kamena vourla
    375 straja
    376 dolores
    377 eminabad
    378 rincon viejo
    379 wollerau
    380 excelsior springs
    381 mizunami
    382 taremskoye
    383 stara moravica
    384 rastede
    385 elati
    386 puerto concordia
    387 sunzha
    388 stryn
    389 doctor cecilio baez
    jaipur hat was not found.
    390 balogo
    391 sadovo
    392 pogaceaua
    393 formello
    394 ayala
    395 nueva gorgona
    396 grua
    397 almendralejo
    398 kishanganj
    399 winter garden
    400 alvik
    401 alasehir
    402 colonia
    403 beau vallon
    404 losal
    mahaena was not found.
    405 tazmalt
    406 itajuba
    407 saarbrucken
    408 agalatovo
    409 navegantes
    410 strakonice
    411 milford
    412 salgar
    413 las cumbres
    414 catina
    415 rajpur
    416 rodeo
    417 saint-mande
    418 arganil
    419 desa
    420 boa esperanca
    421 chiclana
    duzici was not found.
    422 hasbrouck heights
    423 lakeland highlands
    424 purikay
    425 azangaro
    426 morro agudo
    427 saint petersburg
    428 putyatino
    429 aylesbury
    430 am timan
    431 haizhou
    432 losevo
    433 sawang daen din
    434 skjold
    435 soledade
    436 bolisong
    437 ceyranbatan
    438 lyubotyn
    439 santa rosa de viterbo
    440 laives
    441 mvuma
    uwayl was not found.
    442 zhenhai
    443 balta doamnei
    444 bethalto
    445 nea vissa
    446 axim
    447 valenzuela
    448 new cassel
    449 santa helena
    450 kletnya
    451 middlebury
    452 shinyanga
    453 alcobendas
    454 civita castellana
    455 mabama
    yershov was not found.
    456 kalanchak
    457 seraing
    458 buraydah
    459 guisijan
    460 abatskoye
    461 ipiau
    462 zhavoronki
    463 seaca de camp
    464 dunaszekcso
    465 kolt
    466 salinas
    467 coswig
    468 maynooth
    targu bujor was not found.
    469 manduria
    470 ballinrobe
    471 moses lake
    472 horadiz
    473 moron
    474 spantov
    475 bajah
    476 erdotelek
    477 bukit baru
    478 orasac
    479 pulong santol
    480 dmitrov
    481 zhetysay
    umm durman was not found.
    482 nolinsk
    483 maryville
    484 kamloops
    485 new milford
    486 ho chi minh city
    487 hopewell
    488 las juntas
    chigorodo was not found.
    489 vershino-shakhtaminskiy
    490 kibaya
    491 tupancireta
    492 ajaigarh
    493 orasac
    494 tel aviv-yafo
    495 rastatt
    496 arieseni
    497 arkhonskaya
    498 sittingbourne
    499 macmerry
    500 orasu nou
    501 eratira
    502 siuri
    503 college park
    504 cuza voda
    505 tequixquitla
    506 petersburg
    507 lishan
    508 grude
    509 santo augusto
    510 itapevi
    511 mobara
    512 suket
    513 gramalote
    514 kompaniyivka
    515 mafra
    516 armenis
    517 bansko
    518 veresti
    519 santa teresa
    520 searcy
    521 pueblo nuevo
    522 dandeli
    523 calaoagan
    524 caldogno
    525 san antonio de la cal
    526 san francisco
    527 khatauli
    528 libas
    529 vaihingen
    530 ixtapa
    531 peachtree city
    532 egersund
    533 paamiut
    534 rajkot
    535 buduslau
    536 karlovo
    537 jambusar
    538 quibor
    539 rio verde de mato grosso
    540 khiri mat
    541 castletown
    542 talcahuano
    543 skoczow
    544 libenge
    545 siquijor
    546 galegos
    547 san juan del cesar
    548 bailieborough
    549 finschhafen
    soloma was not found.
    550 zaragoza
    551 assiros
    552 moron
    553 dok kham tai
    554 sacalum
    555 naarden
    556 topolcani
    557 sarosd
    558 san fernando
    559 doha
    560 copalau
    561 brvenica
    562 fountain valley
    gilazi was not found.
    563 moi
    564 tipolo
    565 culianin
    566 tago
    567 naeni
    568 jua
    569 liuhe
    570 titagarh
    571 vrbno pod pradedem
    572 sanghar
    573 visegrad
    574 fratesti
    575 wilkinsburg
    576 amas
    577 paiania
    578 ierapetra
    579 san felipe
    580 stockach
    581 druzhba
    582 waconia
    583 patillas
    584 providence
    kota bahru was not found.
    585 tagas
    586 belo jardim
    587 torri di quartesolo
    588 staryy nadym
    589 cancun
    590 windhoek
    591 khndzoresk
    592 issoire
    593 twistringen
    594 kremnica
    595 bouillon
    ptolemais was not found.
    596 neerijnen
    597 covington
    598 perepravnaya
    599 lonar
    600 sussex
    601 presidente olegario
    602 muros
    603 nirasaki
    604 mirpur mathelo
    605 lipa
    606 humble
    607 rijkevorsel
    608 guantanamo
    lephepe was not found.
    609 fatehabad
    610 morada nova
    611 makakilo city
    cegrane was not found.
    612 nattarasankottai
    613 lunavada
    614 hamada
    taolanaro was not found.
    615 hanno
    616 jemnice
    617 buwenge
    staromaryevka was not found.
    618 somma lombardo
    619 victorville
    620 katol
    papeari was not found.
    621 rakvere
    622 jaguarari
    623 berdsk
    rusca montana was not found.
    624 yali
    625 belcista
    subaytilah was not found.
    626 hodkovice nad mohelkou
    galchino was not found.
    627 farmington
    628 valga
    629 sortavala
    630 saint george
    631 macapsing
    632 ilhabela
    633 bom conselho
    634 brekstad
    635 olaya
    636 clinton
    rajauri was not found.
    637 anstruther
    carjiti was not found.
    638 alabat
    639 ghizela
    640 vysokyy
    641 san fabian
    642 nur
    643 zorak
    644 el reno
    karauzyak was not found.
    645 kharela
    646 palaikastron
    647 igbaras
    belogradcik was not found.
    648 sasaram
    649 westfield
    650 igreja nova
    651 tlucna
    cubarral was not found.
    652 tchollire
    653 ranavav
    654 simao dias
    655 wellin
    656 balading
    657 earlston
    658 desaguadero
    659 guirang
    660 numaran
    661 uplawmoor
    kaspican was not found.
    662 songculan
    663 georgetown
    paramithia was not found.
    ascension was not found.
    664 nordenham
    665 aklera
    666 sibanicu
    667 amarpatan
    668 villa de reyes
    669 lakes entrance
    670 fujishiro
    671 aggugaddan
    672 nikolayevskaya
    673 clute
    674 lourosa
    675 apollonia
    676 arnprior
    677 kultuk
    678 westborough
    679 marinhais
    680 boulogne-billancourt
    681 athol
    682 llano de piedra
    683 hervey bay
    684 luanda
    685 matsudo
    686 kyaiklat
    sirfa was not found.
    687 nangka
    688 riyadh
    689 porosozero
    690 agrestina
    691 sezze
    692 gamay
    693 lamont
    694 bogense
    695 butuan
    696 supata
    697 san prisco
    698 carabalan
    699 bessemer
    eforie was not found.
    700 imaculada
    701 machiques
    702 las delicias
    703 lao
    704 munhall
    705 sao sebastiao do paraiso
    706 watrous
    707 talgram
    708 meru
    709 takahata
    710 labuan
    711 neustadt
    712 consuegra
    713 jandaia do sul
    714 nambucca heads
    715 buyukcavuslu
    716 yelets
    717 rivera
    718 pechenizhyn
    719 chirnogeni
    toungoo was not found.
    720 serici
    721 gary
    tanquian was not found.
    722 salzano
    723 algiers
    724 oignies
    725 los zacatones
    726 mukacheve
    727 vyskov
    728 coral springs
    729 qixingtai
    730 parscov
    731 salingogon
    732 grosseto
    733 west lafayette
    734 herten
    735 guiren
    736 el ocotito
    737 duyun
    738 novorossiysk
    739 llanelli
    740 antananarivo
    741 ecser
    742 uniontown
    urosevac was not found.
    743 haaksbergen
    744 baependi
    745 sin-le-noble
    746 khebda
    747 tucuru
    748 canelas
    749 karangasem
    750 lucea
    751 dreieich
    752 livny
    753 vostochnyy
    754 valpacos
    755 dobroye
    756 bauska
    757 mandal
    758 sanski most
    759 tumsar
    760 primalkinskoye
    761 ion roata
    762 novoukrayinka
    763 erba
    764 pesqueira
    765 hereford
    766 atok
    767 rock hill
    768 konnur
    769 santo nino
    770 tablas
    771 dyurtyuli
    772 chingirlau
    773 gelsenkirchen
    774 wai
    775 steinen
    776 nyirmihalydi
    777 mendeleyevo
    778 hirosaki
    779 vester hassing
    780 ryde
    781 maryville
    782 abilene
    783 fort saint james
    784 svobodnyy
    785 svecha
    786 dalaoig
    787 shimoni
    788 vresina
    789 lasang
    790 kaluga
    791 ilog
    792 maricka
    793 green valley
    794 wittstock
    795 repino
    796 dornoch
    797 pemex
    798 carmignano
    799 motegi
    800 manjeshwar
    801 xinan
    802 mata del nance
    803 orange
    804 trinidad
    805 zeltweg
    806 chhibramau
    807 garden city
    808 brookhaven
    809 abilay
    810 puerto penasco
    nea zikhni was not found.
    811 soplaviento
    812 sasvad
    813 monte plata
    814 balinad
    815 chavakachcheri
    816 keene
    tlaxiaco was not found.
    817 qufu
    skagastrond was not found.
    818 clayton
    819 alfonsine
    820 bangor
    821 verkh-chebula
    822 kurbnesh
    823 macalelon
    karomatan was not found.
    824 bogatyr
    maciuca was not found.
    825 xuchang
    826 valle de guadalupe
    827 molinella
    828 ciocanesti
    829 rakvice
    830 kings point
    831 kiskunfelegyhaza
    832 ibirapitanga
    grimari was not found.
    833 gaitanion
    834 solana
    835 haysyn
    836 maya
    837 nikolskoye
    838 kikuchi
    839 magpet
    840 csokmo
    841 codcod
    842 longford
    843 camacari
    844 yopal
    845 mae tha
    846 sakai
    847 san diego
    848 episkopi
    849 calgary
    850 gaoua
    851 agdangan
    852 telciu
    853 sunam
    854 noale
    855 giddalur
    856 mayenne
    857 mions
    858 lerum
    linshu was not found.
    859 pontalina
    860 borlesti
    861 snihurivka
    862 elban
    863 hanesti
    864 evergem
    865 matehuala
    866 bosanska krupa
    867 burtunay
    868 masaki
    869 novoaltaysk
    870 nueva esperanza
    871 el llano
    872 el balsamo
    873 friendswood
    874 bodo
    875 pfaffikon
    876 needham
    877 cocoa
    878 savinka
    cadagmayan was not found.
    879 ngong
    880 getashen
    881 ilinskiy
    882 vetrisoaia
    883 cieszyn
    884 baruta
    885 crystal lake
    886 middlesbrough
    887 biggar
    888 north massapequa
    magallon was not found.
    bac can was not found.
    889 myingyan
    890 piatra olt
    891 shahabad
    892 schenefeld
    apatzingan was not found.
    893 prattville
    894 sinesti
    895 esenyurt
    896 broumov
    897 bocas del toro
    898 amontada
    899 silistea
    900 maamba
    901 bongued
    valea marului was not found.
    902 lendelede
    903 kauhajoki
    904 nagyszenas
    905 malm
    906 faya
    907 turceni
    908 kantyshevo
    909 murici
    slobozia-conachi was not found.
    910 nindiri
    911 mlati
    912 quartz hill
    913 mabini
    914 broomfield
    915 yellowknife
    chelyabinsk-70 was not found.
    916 prosperous
    917 santa catarina
    eskasem was not found.
    918 yuryuzan
    919 bitlis
    920 silay
    ojitlan was not found.
    921 oga
    922 ocotepec
    923 veyrier
    924 delemont
    925 bansdih
    926 detmold
    927 libas
    928 germantown
    929 redcar
    930 san francisco del rincon
    931 danao
    932 eidsvag
    933 teo
    934 husavik
    935 visconde do rio branco
    936 adeje
    937 linkoping
    938 glazunovka
    939 hajdusamson
    940 volchikha
    941 pulsano
    942 la guaira
    943 winter springs
    944 zuhres
    945 shedok
    946 chiheru de jos
    947 chaguanas
    948 vilnius
    949 duffel
    950 woodland
    951 villa de san antonio
    952 kabalo
    953 fitionesti
    954 sindang
    vironia was not found.
    955 izumo
    956 bradeanu
    957 majalgaon
    958 hukuntsi
    959 wenden
    960 laki
    961 saumur
    962 corato
    963 paptalaya
    964 chemnitz
    965 kontagora
    966 minas
    967 ayakudi
    968 makoshyne
    969 trifesti
    970 binanwanaan
    971 sioni
    972 pirogovo
    973 morbach
    974 shahpura
    975 mercato san severino
    976 nakkila
    977 piney green
    978 mubi
    979 tessalit
    980 fundong
    981 queimadas
    jazzin was not found.
    982 simoes
    983 baza
    984 ikryanoye
    985 kharabali
    986 carrieres-sous-poissy
    987 orocuina
    988 lysa nad labem
    989 nanchang
    990 vendychany
    991 ladario
    992 montecillo
    993 soddy-daisy
    994 halayhay
    995 turbana
    996 kheri
    997 seydisehir
    998 numata
    999 bosanska gradiska
    panchiao was not found.
    1000 banda aceh
    puerto gaitan was not found.
    1001 libertador general san martin
    1002 los angeles
    


```python
# Tabulate the random weather.
df_weather = pd.DataFrame(random_weathers)

# Move the city to the row index.
df_weather = df_weather.T

# Move the city index to a column.
df_weather = df_weather.reset_index()

# Rename the index column to city
df_weather = df_weather.rename(columns={"index":"City"})


# Show first five rows.
df_weather.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloudiness</th>
      <th>Country</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Lat</th>
      <th>Lng</th>
      <th>Max Temp</th>
      <th>Wind Speed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>abatskoye</td>
      <td>44</td>
      <td>RU</td>
      <td>1520894484</td>
      <td>74</td>
      <td>56.29</td>
      <td>70.46</td>
      <td>-6.3</td>
      <td>3.27</td>
    </tr>
    <tr>
      <th>1</th>
      <td>abilay</td>
      <td>36</td>
      <td>PH</td>
      <td>1520894652</td>
      <td>94</td>
      <td>10.73</td>
      <td>122.5</td>
      <td>76.24</td>
      <td>12.66</td>
    </tr>
    <tr>
      <th>2</th>
      <td>abilene</td>
      <td>1</td>
      <td>US</td>
      <td>1520892900</td>
      <td>30</td>
      <td>32.45</td>
      <td>-99.73</td>
      <td>59</td>
      <td>6.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>adeje</td>
      <td>0</td>
      <td>NG</td>
      <td>1520894714</td>
      <td>92</td>
      <td>5.68</td>
      <td>5.76</td>
      <td>76.69</td>
      <td>6.17</td>
    </tr>
    <tr>
      <th>4</th>
      <td>adil-yangiyurt</td>
      <td>0</td>
      <td>RU</td>
      <td>1520894328</td>
      <td>85</td>
      <td>43.56</td>
      <td>46.58</td>
      <td>21.38</td>
      <td>5.95</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Start and end dates.
min_date = df_weather['Date'].min()
min_date_str = datetime.datetime.fromtimestamp(int(min_date)).strftime('%Y-%m-%d')

max_date = df_weather['Date'].max()
max_date_str = datetime.datetime.fromtimestamp(int(max_date)).strftime('%Y-%m-%d')

if (min_date_str == max_date_str):
    date_str = min_date_str
else:
    date_str = "{0} through {1}".format(min_date_str, max_date_str)
    
print(date_str)
```

    2018-03-12
    


```python
# University of Southern California
USC = {}

url = "http://api.openweathermap.org/data/2.5/weather?"

city_name = "los angeles"
country_code = "US"

query_url = "{0}appid={1}&q={2},{3}&units=imperial".format(url, api_key, city_name, country_code)

weather_response = requests.get(query_url)

weather_json = weather_response.json()
    
try:
    USC['Max Temp'] = weather_json.get('main').get('temp_max')
    USC['Humidity'] = weather_json.get('main').get('humidity')
    USC['Lng'] = weather_json.get('coord').get('lon')
    USC['Lat'] = weather_json.get('coord').get('lat')
    USC['Date'] = str(weather_json.get('dt'))
    USC['Cloudiness'] = weather_json.get('clouds').get('all')
    USC['Country'] = weather_json.get('sys').get('country')
    USC['Wind Speed'] = weather_json.get('wind').get('speed')
except AttributeError:
    print(city_name, "was rejected. #############################")
    
print(json.dumps(USC, indent=4, sort_keys=True))       
```

    {
        "Cloudiness": 75,
        "Country": "US",
        "Date": "1520894220",
        "Humidity": 82,
        "Lat": 34.05,
        "Lng": -118.24,
        "Max Temp": 77,
        "Wind Speed": 11.41
    }
    

<h2>Latitude vs Temperature Plot</h2>


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Max Temp'])
plt.scatter(x_axis, y_axis)

# Format axis
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-20,130,10))

# Format labels
plt.xlabel('Latitude')
plt.ylabel('Max Temperature (F)')
plt.title('City Latitude vs. Max Temperature (' + date_str + ')')


# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)  
vertical_location = -32
plt.text(65.5,vertical_location, 'Artic Circle', rotation=90)
plt.text(22.5,vertical_location, 'Tropic of Cancer', rotation=90)
plt.text(-0.5,vertical_location, 'Equator       ', rotation=90)
plt.text(-23.5,vertical_location, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5,vertical_location, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, vertical_location, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Max Temp'), color='red')
plt.text(-95, USC.get('Max Temp') -0.1, 'USC', color='red')


plt.show()
```


![png](output_12_0.png)


<h2>Latitude vs. Humidity Plot


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Humidity'])
plt.scatter(x_axis, y_axis)

# Format axis.
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 110, 10))

# Add labels
plt.xlabel('Latitude')
plt.ylabel('Humidity')
plt.title('City Latitude vs. Humidity (' + date_str + ')')



# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5,-15, 'Artic Circle', rotation=90)
plt.text(22.5,-15, 'Tropic of Cancer', rotation=90)
plt.text(-0.5,-15, 'Equator       ', rotation=90)
plt.text(-23.5,-15, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5,-15, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -15, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Humidity'), color='red')
plt.text(-95, USC.get('Humidity') -0.1, 'USC', color='red')


plt.show()
```


![png](output_14_0.png)


<h2>Latitude vs. Cloudiness Plot</h2>


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Cloudiness'])
plt.scatter(x_axis, y_axis)

# Format axis.
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 110, 10))

# Add labels
plt.xlabel('Latitude')
plt.ylabel('Cloudiness')
plt.title('City Latitude vs. Cloudiness (' + date_str + ')')

# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5, -15, 'Artic Circle', rotation=90)
plt.text(22.5, -15, 'Tropic of Cancer', rotation=90)
plt.text(-0.5, -15, 'Equator       ', rotation=90)
plt.text(-23.5, -15, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5, -15, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -15, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Cloudiness'), color='red')
plt.text(-95, USC.get('Cloudiness') -0.1, 'USC', color='red')


plt.show()
```


![png](output_16_0.png)


<h2>Latitude vs. Wind Speed Plot


```python
plt.figure(figsize=(20,12))
x_axis = list(df_weather['Lat'])
y_axis = list(df_weather['Wind Speed'])
plt.scatter(x_axis, y_axis)

# Format axis
plt.xticks(np.arange(-90,100,10))
plt.yticks(np.arange(-10, 50, 10))

plt.xlabel('Latitude')
plt.ylabel('Wind Speed (MPH)')
plt.title('City Latitude vs. Wind Speed (' + date_str + ')')


# Draw major latitudes.
xcoords = [66, 23, 0, -23, -66]
for xc in xcoords:
    plt.axvline(x=xc)    
plt.text(65.5, -12, 'Artic Circle', rotation=90)
plt.text(22.5, -12, 'Tropic of Cancer', rotation=90)
plt.text(-0.5, -12, 'Equator       ', rotation=90)
plt.text(-23.5, -12, 'Tropic of Capricorn', rotation=90)
plt.text(-66.5, -12, 'Antartic Circle', rotation=90)

# University of Southern California
plt.axvline(USC.get('Lat'), color='red')    
plt.text(USC.get('Lat') - 0.5, -12, 'USC', rotation=90, color='red')
plt.axhline(USC.get('Wind Speed'), color='red')
plt.text(-95, USC.get('Wind Speed') -0.1, 'USC', color='red')


plt.show()
```


![png](output_18_0.png)

